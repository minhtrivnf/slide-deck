---
name: vnf-slidedeck-generator
description: "Use this skill to convert any research report or policy document into a structured VNF-branded PowerPoint slide deck (~55-65 slides, based on content depth) with consultancy-grade storyline (BCG/McKinsey conventions: action titles, pyramid principle, MECE arguments, so-what takeaways) and 24 layout patterns. Trigger whenever the user uploads or references a Word document (.docx) and wants slides, a presentation, or a deck made from it. Also trigger on phrases like 'tạo slide từ báo cáo', 'tạo deck', 'create presentation from report', 'turn this report into slides', 'generate slide deck', or any request to transform a document into a PowerPoint. Always use this skill — even if the user just says 'make slides from this' — when a report document is involved."
---

# VNF Slide Deck Generator (v2 — Consultancy Grade)

This skill transforms a research or policy report (Word .docx) into a professional VNF-branded PowerPoint presentation (~55–65 slides, based on content depth) following the Deep-Tech Framework 7-layer structure AND the consultancy storyline conventions used by BCG / McKinsey / Bain / Roland Berger.

**v2 changes**:
- Expanded from 9 → 24 layout patterns (adds Executive Summary, Pyramid, Waterfall, BCG 2×2, Harvey Balls, Heat Map, Driver Tree, Roadmap, Maturity Radar, Three-Horizon, Ecosystem, KPI Scorecard, Agenda, Source/Method, Build).
- Action titles (descriptive sentences stating conclusions) now standard on insight slides.
- Kicker (UPPERCASE eyebrow), source line (Zone 3), and so-what takeaway (Zone 4) added to per-slide template.
- Calibri-only enforcement (legacy Montserrat references removed from templates).
- Semantic status palette + categorical chart palette + sequential heat-map ramp.
- New QA checks for action-title coherence, pyramid structure, and source citations.
- **Step 1 reading is now agent-driven**: probe the docx first, then pick the right tool (docx skill / python-docx / pandoc / mammoth / markitdown) instead of forcing a single converter. Embedded media is extracted to disk for reuse on slides.

**v2.2 changes (simplified after v2.1 regressions + file-integrity gates + Pyramid connector fix)**:
- **NEW: pre-delivery file-integrity gates.** Three sequential checks before delivering: (Gate A) pre-pack XML validation for duplicate IDs / missing rels, (Gate B) python-pptx + LibreOffice open-test, (Gate C) visual spot-check. Catches the "won't open in PowerPoint" class of bugs caused by duplicate `cNvPr id`, `rIdN`, or `sldId`.
- **NEW: validator script** (`scripts/validate_pptx_unpacked.py`) provided in `slide_guide.md` for the Gate A check.
- **Pattern 11 (Pyramid) connector geometry fixed.** Top tier widened to cx=5486400 to fit the governing-thought sentence. Connector geometry made explicit: 3 lines from top-box bottom-center fanning to each lower-box top-center, with `flipH="1"` required on the down-LEFT diagonal. Uses `<a:stCxn>` / `<a:endCxn>` anchor IDs so connectors stay attached if shapes move.
- **Connector geometry rule documented**: `off=min(A,B)`, `ext=|B-A|`, `flipH/flipV` set when going right→left or bottom→top. Applies to Pattern 11 (Pyramid), Pattern 16 (Driver Tree), Pattern 20 (Ecosystem) — anywhere connectors are used.
- **Kicker / eyebrow textbox REMOVED from the default zone model.** It produced an extra textbox at the top of every slide that pushed the title down. Section context already lives in the master's footer label. Use only when the user explicitly asks.
- **Manual Title Underline component REMOVED.** The v2.1 manual underline was drawing alongside the master's underline → double-line bug. v2.2 rule: never draw a manual horizontal line under the title. Trust the master.
- **Action titles must be single line.** ≤80 chars at 24pt, or 80–100 chars at 20pt. NEVER let titles wrap to 2 lines (wrapping crosses the master's underline).
- **Action title moved to y=0** (top of slide), since there's no kicker above it.
- **Source line moved ABOVE the tagline** at y=5436000 (15.1cm). The previous position below the tagline was crossing the master's footer separator at ~17.8cm.
- **Bottom-stack order updated**: Content → Source → Tagline → Footer (top to bottom). Source now sits above the tagline.
- **17.5–18.2cm is reserved for master decorations.** Agent never places anything in this band.
- **Tagline polish carried forward from v2.1**: rounded `roundRect adj=4500` corners, no literal "SO WHAT" prefix by default.

## Workflow Overview

```
Step 1: Read the report (.docx)
        → Probe structure first (unzip -l)
        → Pick the reading tool that fits the content (docx skill / python-docx / pandoc / mammoth / markitdown)
        → Extract embedded media for slide reuse
Step 2: Generate detailed outline (7-layer structure, action titles, flexible slide allocation)
Step 3: Build PPTX from outline using VNF template (24 patterns available)
Step 4: QA — visual + storyline coherence
```

All steps use bundled reference guides — read them before starting.

---

## Reference Files Architecture

This skill uses a **multi-file architecture** for efficiency and context management:

### Outline Generation Files

```
references/
├── outline_guide.md          # Workflow, 7-layer structure, action-title storyline, QA
└── (generated outlines/)
    ├── outline-master.md     # Overview, metadata, action-title skim
    ├── outline-layer-1.md    # Science Layer (Fields 1-4)
    ├── outline-layer-2.md    # Technology Layer (Fields 5-8)
    ├── outline-layer-3.md    # Industrial Layer (Fields 9-12)
    ├── outline-layer-4.md    # Market Layer (Fields 13-16)
    └── outline-layer-5.md    # Strategic + Architecture + Applied (Fields 17-31)
```

### Slide Building Files

```
references/
├── slide_guide.md            # Workflow, consultancy storyline principles, QA
├── slide_specs.md            # Dimensions, colors (incl. semantic + categorical), typography (action title, kicker, source)
├── slide_patterns.md         # 24 layout patterns with coordinates (P1–P9 foundational + P10–P24 consultancy)
└── slide_templates.md        # Reusable XML component templates (Calibri-reconciled)
```

### When to Load Each File

| Task | File(s) to Load |
|------|-----------------|
| Outline workflow | `references/outline_guide.md` |
| Creating outline master | `references/outline_guide.md` |
| Creating layer outlines | `references/outline_guide.md` |
| Slide-build workflow + storyline | `references/slide_guide.md` |
| Design specs (dimensions, colors, typography, semantic tokens) | `references/slide_specs.md` |
| Choosing one of 24 patterns | `references/slide_patterns.md` |
| Building slide XML | `references/slide_templates.md` |

---

## Step 1: Read the Report (Agent-Driven Tool Selection)

The user attaches a `.docx` report. **The agent picks the best reading tool based on what's actually inside the file** — there is no fixed command. Different reports need different extraction strategies.

### 1A. Probe First (Always)

Before extracting, peek at the docx structure. A `.docx` is a ZIP archive — listing it reveals which content types are present:

```bash
unzip -l /path/to/report.docx
```

Look for these signals:

| File present | Signal | Implication |
|--------------|--------|-------------|
| `word/media/*` | Embedded images / charts | Need to extract media to disk for slide reuse |
| `word/charts/*` | Native charts | Mammoth or python-docx required to preserve |
| `word/footnotes.xml` | Footnotes | Pandoc preserves; markitdown may flatten |
| `word/endnotes.xml` | Endnotes | Same as footnotes |
| `word/comments.xml` | Reviewer comments | Often diagnostic — read with python-docx |
| `word/people.xml` + revisions | Tracked changes | Pandoc `--track-changes=all` |
| Many `<w:tbl>` in `document.xml` | Heavy tables | python-docx or pandoc, NOT markitdown |
| `word/embeddings/*` | Embedded Excel / objects | Extract separately |

A 1-second probe tells you which path to take. Skipping the probe and going straight to markitdown silently degrades output on table-heavy or chart-heavy reports — exactly what VNF policy reports tend to be.

### 1B. Pick the Reading Tool

Apply the tiered decision tree:

| Report content | Recommended tool | Why |
|----------------|------------------|-----|
| Default / unknown | **`docx` skill** (`anthropic-skills:docx`) | Bundled best-practice handler; preserves structure, comments, formatting via python-docx |
| Plain prose, no tables/charts/images | `markitdown` | Fastest path to clean markdown |
| Heavy tables (technical specs, comparison tables) | `python-docx` (iterate `doc.tables`) **or** `pandoc -f docx -t gfm` | Preserves cell structure, merges, headers |
| Embedded images / charts to reuse on slides | `python-docx` + extract `word/media/*` to `/extracted_media/` | Lets you reuse the originals as slide assets (Pattern 5 icons, Pattern 20 ecosystem nodes) |
| Footnotes / endnotes / academic citations | `pandoc -f docx -t markdown` | Preserves footnote markers and citation references |
| Tracked changes / reviewer comments | `pandoc --track-changes=all` **or** `python-docx` reading `comments.xml` | Surfaces revision history that markitdown drops |
| Equations / formulas | `pandoc -f docx -t markdown+tex_math_dollars` | Preserves math via LaTeX |
| Mixed (most VNF reports) | **`docx` skill first**, then `python-docx` for table extraction, then `markitdown` for narrative chunks | Compose tools; don't rely on one |

### 1C. Always Extract Media to Disk

If the probe shows `word/media/`, extract it once and keep the assets:

```bash
mkdir -p extracted_media
unzip -j /path/to/report.docx 'word/media/*' -d extracted_media/
```

These assets become reusable on slides — original charts, photos, diagrams, brand marks — instead of regenerating them. Reference them in the outline's "Content from report" field so the slide builder can place them.

### 1D. Read the Content

Once extracted, read and understand the full content before generating the outline. Note: key topics, data points, findings, recommendations, **plus** an inventory of available media assets — all of these anchor the outline.

**What NOT to do**:
- ❌ Default to a single command (`python -m markitdown ...`) without inspecting the file
- ❌ Skip media extraction — you'll regenerate visuals you already have
- ❌ Treat tables as text — use a tool that preserves cell structure
- ❌ Drop footnotes silently — they often contain the source citations you need for Zone 3
- ❌ Ignore tracked changes / comments — they often signal what's still in dispute

**What TO do**:
- ✅ Probe first (`unzip -l`)
- ✅ Choose the tool that fits the content
- ✅ Extract media to disk for reuse
- ✅ Capture footnotes / citations for source-line use
- ✅ Compose multiple tools when the report is heterogeneous

---

## Step 2: Generate the Slide Outline

Read **`references/outline_guide.md`** for the full guidelines.

### Multi-File Outline Process

Generate the outline in **6 separate files** for efficiency:

1. `outline-master.md` — Overview, metadata, cross-layer narrative, **action-title skim**
2. `outline-layer-1.md` — Science Layer (Fields 1–4)
3. `outline-layer-2.md` — Technology Layer (Fields 5–8)
4. `outline-layer-3.md` — Industrial Layer (Fields 9–12)
5. `outline-layer-4.md` — Market Layer (Fields 13–16)
6. `outline-layer-5.md` — Strategic + Architecture + Applied (Fields 17–31)

### The 7-Layer Deep-Tech Framework

Slide counts are determined by **content depth and importance**, not fixed numbers:

| Layer | Name | Fields | Anchor Pattern |
|-------|------|--------|----------------|
| 1 | Science Layer | 1–4 | P16 Driver tree / P11 Pyramid |
| 2 | Technology Layer | 5–8 | P14 Harvey Balls / P13 BCG 2×2 |
| 3 | Industrial Layer | 9–12 | P20 Ecosystem / P17 Roadmap |
| 4 | Market Layer | 13–16 | P12 Waterfall / P15 Heat map |
| 5 | Strategic Layer | 17–20 | P6 SWOT + P18 Maturity radar |
| 6 | Strategic Architecture | 21–26 | P19 Three-horizon + P11 Pyramid |
| 7 | Applied Strategy | 27–31 | P17 Roadmap + P21 KPI scorecard |

**Total**: ~55–65 slides (1 cover + 1 agenda + 7 layer dividers + 1 source/method + content slides)

**CRITICAL**: Allocate slides based on meaning and importance, NOT fixed numbers.

### The Consultancy Storyline (NEW — v2)

Three principles drive every outline entry:

1. **Action Titles, Not Topic Titles** — Insight slides lead with a descriptive sentence stating the conclusion (e.g. "Asia-Pacific demand will outpace global growth by 2.4× through 2030"), not a topic name. Skim of action titles must reconstruct the argument.
2. **Pyramid Principle (Minto)** — Each slide answers a question with the answer first (governing thought), then 3 MECE supporting arguments, then evidence.
3. **"So What" Takeaways** — Every analytical slide ends with a Zone 4 blue box that states the **implication** for the reader, not a restatement of the title.

### Per-Slide Outline Entry (v2)

For every slide, write:

- **Objective**: What the audience learns or decides
- **Action Title**: Descriptive sentence stating the conclusion (≤140 chars, 1–2 lines)
- **Short Headline (alt)**: 3–5 word topic — only on layer dividers / agenda / source slides
- **Kicker**: UPPERCASE eyebrow ("LAYER · FIELD TOPIC")
- **Content from Report**: Specific data, quotes, findings to use
- **Source citation**: "Source: …" — required when citing third-party data
- **Presentation pattern**: One of P1–P24 from `slide_patterns.md`
- **So-what takeaway**: Zone 4 blue-box implication (10–20 words)
- **Transition to next**: How this slide connects to the next

### Field-Level Elements

Each field must include:
- **Field Title** (10–15 words): Summary appearing across all slides in the field
- **Field Tagline / Takeaway** (10–20 words): Closing implication that appears in the **TAGLINE zone** (blue box at bottom of content area, Zone 4) on the field's final slide

**CRITICAL**: The field tagline is NOT the footer. It's a Zone 4 blue textbox containing the "so what" implication. The agent MUST create it. The footer (Zone 5) is automatic from the slide master.

### QA Phase

After generating outlines, run the **Storyline Coherence Check** from `outline_guide.md`:
- Slide-to-slide connections
- Narrative arc (setup → development → climax → resolution)
- Cross-layer transitions
- **Action-title skim test**: skim only action titles in sequence — must read as a coherent argument
- **So-what test**: every Zone 4 takeaway states implication, not restatement

---

## Step 3: Build the Slide Deck

Read **`references/slide_guide.md`** for the full workflow.

### ⚠️ CRITICAL: Mandatory 3-Step Process

**Template Location**: `assets/vnf_slide_template.pptx`

**STEP 1: Clone the template**
- Copy `assets/vnf_slide_template.pptx` to working directory
- This becomes your new slide deck
- **NEVER create a presentation from scratch**

**STEP 2: Use the cover page**
- Keep slide 1 (cover) from the cloned file
- **ONLY replace the title text** with the new slide deck's title
- **DO NOT modify** any other elements (logo, brand logos, contact info, decorative elements)

**STEP 3: Append subsequent slides**
- Add all new content slides AFTER the cover slide
- Each new slide MUST:
  - Apply the **"Content" layout** from the slide master (provides separator + footer automatically)
  - Follow VNF style guidelines (Calibri only, 4:3 ratio, 15-color palette + semantic tokens)
  - Use action titles + kickers + source lines + takeaways per the consultancy storyline
- **NEVER create slides from scratch** — always use the "Content" layout

### Template Structure

The cloned template contains:
- **Slide Master** — Pre-configured with **Calibri**, navy color scheme, layout placeholders
- **Slide 1 (Cover)** — Logo, brand logos, contact info. **Keep and replace title only.**
- **"Content" Layout** — Apply to ALL new content slides (provides separator + footer)

### VNF Slide Specifications

| Property | Value |
|----------|-------|
| Aspect ratio | 4:3 |
| Dimensions | 25.40 × 19.05 cm (9144000 × 6858000 EMU) |
| Font | **Calibri ONLY** — no other fonts permitted |
| Grid | 12 columns × 1.91 cm wide, gutter 0.32 cm |
| Safe margin | 1.27 cm all sides |
| Cover title | 48pt bold white on navy |
| Action title | 24pt bold Navy đậm `002060` — single line, ≤80 chars (drop to 20pt if 80–100 chars) |
| Short title | 20pt bold Navy đậm `002060` (dividers / ToC) — single line |
| Kicker | DEPRECATED in v2.2 — do not add by default |
| Body text | 13pt Calibri Body `2C2C2C` |
| Source line | 9pt italic Gray `888888` — sits ABOVE the tagline at y=5436000 |

### Color Palette (VNF Brand 15-Color + Semantic Extensions)

| Role | Hex | Usage |
|------|-----|-------|
| Navy chính | `1F497D` | Brand identity |
| Navy đậm | `002060` | Slide titles, action titles |
| Navy trầm | `002F69` | Navy variant |
| Đỏ chính | `953735` | **PRIMARY emphasis** (most used), kickers |
| Đỏ critical | `C00000` | Warnings, danger status |
| Xanh da trời | `D6F1FC` | Takeaway boxes (Zone 4) |
| Xanh sáng | `0070C0` | Icons, charts series 1, info status |
| Xanh lá | `598C48` | Ecological / success accent |
| Cam đất | `C36518` | Agricultural / warning accent |
| Vàng hổ phách | `E6AF00` | Milestones, highlight rings |
| Body text | `2C2C2C` | Main body |
| Subtle body | `595959` | Secondary body |
| Gray | `888888` | Footer, source line, captions |

**Semantic status (NEW — v2)**:
- Success: dark `2E7D32` / light `E8F5E9`
- Warning: dark `C97A00` / light `FFF4E0`
- Danger:  dark `C00000` / light `FCE4E4`
- Info:    dark `0070C0` / light `D6F1FC`
- Neutral: dark `595959` / light `F2F2F2`

**Categorical chart palette (8 colors)**: `002060 → 0070C0 → 953735 → 598C48 → E6AF00 → C36518 → A99786 → 002F69`

**Sequential ramp (heat maps, 5 steps)**: `EAF2FA → BFD8EC → 7FB1D9 → 2E7BBF → 002060`

### 24 Layout Patterns Available

**Foundational (P1–P9)**:
1. Stat Callout 3-col
2. Stat Callout 2-col
3. Data Table
4. Process Flow
5. Icon Grid
6. Comparison Matrix (SWOT 2×2)
7. Layer Divider
8. Quote Highlight
9. Bar Chart

**Consultancy-grade (P10–P24)**:
10. Executive Summary (Action Title + 3 Pillars)
11. Pyramid Principle (Minto)
12. Waterfall / Bridge Chart
13. BCG 2×2 Matrix (axes + bubbles)
14. Harvey Ball Comparison
15. Heat Map / Risk Matrix
16. Driver Tree / Decomposition
17. Roadmap / Gantt Timeline
18. Maturity Radar (Spider)
19. Three-Horizon Framework (McKinsey)
20. Ecosystem / Stakeholder Map
21. KPI Scorecard
22. Agenda / Table of Contents
23. Source / Methodology
24. Build / Sequential Reveal

See `slide_patterns.md` for coordinates, when-to-use, and visual examples for each.

### Visual-First Design (Critical)

**Content slides must be visual — not text on a white page.**

Each layer should include:
- ≥1 **structural pattern** (P10, P11, P12, P13, P16, P17, or P19) to provide a backbone
- ≥3 **evidence patterns** (P1, P2, P3, P9, P14, P15, P18, P20, P21) for support
- A **closing pattern** (P10 Executive summary, P11 Pyramid, or P21 KPI scorecard)

**Specifically avoid**: title-only slides, white pages with text boxes, or two consecutive slides using the same pattern.

### PPTX Building Workflow (STRICT 3-STEP PROCESS)

**STEP 1: Clone**
```bash
cp assets/vnf_slide_template.pptx working_directory/new_slidedeck.pptx
```

**STEP 2: Update cover title**
1. `python scripts/office/unpack.py "new_slidedeck.pptx" unpacked/`
2. Open `unpacked/ppt/slides/slide1.xml`
3. Find the title text element
4. Replace ONLY the title text
5. **DO NOT modify** any other element

**STEP 3: Append content slides**
1. Analyze slide master in `unpacked/ppt/slideMasters/` and `unpacked/ppt/slideLayouts/`
2. Identify the **"Content" layout**
3. For each content slide:
   - Load `slide_specs.md`, `slide_patterns.md`, `slide_templates.md`
   - Create new slide XML referencing the "Content" layout
   - Build content per VNF style and consultancy storyline
   - Add slide to `unpacked/ppt/slides/`
   - Update `unpacked/ppt/_rels/presentation.xml.rels` and `unpacked/ppt/presentation.xml`
4. `python scripts/clean.py unpacked/`
5. `python scripts/office/pack.py unpacked/ output.pptx --original "assets/vnf_slide_template.pptx"`

**CRITICAL RULES**:
- ✅ Clone template first (STEP 1)
- ✅ Keep cover slide, replace only title (STEP 2)
- ✅ All new slides apply "Content" layout (STEP 3)
- ✅ All text uses Calibri (no Montserrat — fix any legacy refs)
- ✅ Action titles on all insight slides
- ✅ Source lines on all data slides
- ✅ Zone 4 takeaways on all analytical slides
- ❌ NEVER create presentation from scratch
- ❌ NEVER delete cover slide
- ❌ NEVER create slides without "Content" layout
- ❌ NEVER use the same pattern on two consecutive slides

### Layer Storyline Recipe

For a typical 12-slide layer:

```
1. Pattern 22 (Agenda highlight) or P7 (Layer divider) — opener
2. Pattern 10 (Action title + 3 pillars) — layer thesis
3–6. Patterns 1, 12, 14, 16 — evidence (cards, waterfall, Harvey Balls, driver tree)
7–8. Patterns 13, 6 — strategic positioning
9. Pattern 17 (Roadmap) — what we'll do
10. Pattern 21 (KPI scorecard) — how we'll measure
11. Pattern 11 (Pyramid) — argument summary
12. Pattern 7 (Layer divider) — transition
```

---

## Step 4: QA

After building, run **three sequential gates** before delivering. **Do not skip any of them.** Generated PPTX files frequently break because of duplicate XML IDs, malformed relationships, or layout regressions — these gates catch all three failure modes.

### Gate A — Pre-pack XML validation

Before repacking the unpacked/ directory into a .pptx, validate the XML structure:

```bash
python scripts/validate_pptx_unpacked.py unpacked/
```

The validator must check (full implementation in `slide_guide.md` → "File Integrity QA"):
- No duplicate `<p:cNvPr id="N">` shape IDs within any single slide
- No duplicate `<Relationship Id="rIdN">` in `ppt/_rels/presentation.xml.rels`
- No duplicate `<p:sldId>` in `ppt/presentation.xml` (and all sldId ≥ 256)
- All relationship `Target` files exist on disk
- Every slideN.xml has a matching `_rels/slideN.xml.rels`
- Content types declared for every part type used

If any check fails, **fix the XML first — do not pack a broken deck**.

### Gate B — Open-test the packed file

After packing, verify the file actually opens. Run BOTH tests; both must pass.

```bash
# Test 1 — python-pptx parse (catches XML structure issues)
python -c "from pptx import Presentation; p = Presentation('output.pptx'); print(f'OK: {len(p.slides)} slides')"

# Test 2 — LibreOffice headless conversion (catches issues python-pptx tolerates)
soffice --headless --convert-to pdf output.pptx --outdir /tmp/qa_check
test -f /tmp/qa_check/output.pdf && echo "OK: LibreOffice opened the file"
```

If `python-pptx` errors, inspect the slide referenced in the traceback. If `soffice` hangs >60s or fails to produce a PDF, the file is corrupt — fix and rebuild before delivery.

### Gate C — Visual spot-check

Render slides to images and eyeball each layer's first slide:

```bash
pdftoppm -jpeg -r 150 /tmp/qa_check/output.pdf /tmp/qa_check/slide
```

### QA Checklist

**File integrity (NEW v2.2 — check before any visual QA)**:
- [ ] Gate A: pre-pack XML validator (`scripts/validate_pptx_unpacked.py`) reports OK — no duplicate shape IDs, rIds, or sldIds; all relationship targets exist; every slideN.xml has matching _rels.
- [ ] Gate B: `python -c "from pptx import Presentation; Presentation('output.pptx')"` succeeds without error.
- [ ] Gate B: `soffice --headless --convert-to pdf output.pptx` produces a non-empty PDF within 60s.
- [ ] Gate C: spot-check rendered slide images for layout regressions.

**Process verification**:
- [ ] STEP 1 verified: Cloned from `assets/vnf_slide_template.pptx`
- [ ] STEP 2 verified: Cover slide kept, only title replaced
- [ ] STEP 3 verified: All content slides use "Content" layout
- [ ] Cover elements preserved (logo, brand logos, contact info)

**Typography**:
- [ ] All text uses Calibri (no Montserrat or other fonts)
- [ ] Cover title 48pt bold white on navy
- [ ] Action titles 24pt bold Navy đậm on insight slides
- [ ] Short titles 20pt bold Navy đậm on layer dividers / agenda / source
- [ ] Kickers 10pt UPPERCASE Đỏ chính on insight slides
- [ ] Body text 13pt Calibri
- [ ] Source line 9pt italic Gray on data slides

**Color & visual**:
- [ ] Colors match VNF 15-color palette + semantic tokens
- [ ] Each content slide has ≥1 visual element
- [ ] Heat maps, Harvey Balls, status indicators use semantic palette correctly
- [ ] Slide aspect ratio 4:3 (25.40 × 19.05 cm)

**Storyline (NEW — v2)**:
- [ ] Action titles read as a coherent argument when skimmed end-to-end
- [ ] Each insight slide has a kicker (UPPERCASE category)
- [ ] Each analytical slide has a Zone 4 takeaway with implication (not title restatement)
- [ ] Each data-driven slide has a Zone 3 source line
- [ ] Each layer uses ≥1 structural pattern (P10/P11/P12/P13/P16/P17/P19)
- [ ] No two consecutive slides use the same pattern

**Zone integrity**:
- [ ] Zone 4 (TAGLINE) blue box created by agent on analytical slides
- [ ] Zone 5 (FOOTER) automatic from slide master — not manually created
- [ ] Zone 3 (SOURCE) created on data slides

**Layout geometry (v2.2 — simplified)**:
- [ ] **Only one horizontal line under the title** (the master's). Agent has NOT drawn any manual title underline. No `cxnSp` named TitleUnderline in the slide XML.
- [ ] **Action titles are single line.** ≤80 chars at 24pt, or 80–100 chars at 20pt. Nothing wraps to 2 lines.
- [ ] **No kicker textbox at the top.** No "LAYER N · TOPIC" eyebrow above the title (unless user explicitly requested it).
- [ ] **Action title at y=0** (top of slide). Only one title shape — inherited master title placeholder removed.
- [ ] **Source line at y=5436000** (15.1cm), ABOVE the tagline.
- [ ] **Tagline at y=5832000** (16.2cm), `roundRect` with `adj=4500` (rounded corners).
- [ ] **Nothing in the 17.5–18.2cm band** — that band is reserved for the master's footer separator and footer text.
- [ ] **Bottom-stack order**: Content → Source → Tagline → Footer (top to bottom), with no overlap.
- [ ] **No literal "SO WHAT"** on the tagline by default. Only present on headline action / decision slides; most slides have no prefix or use `→`.

**Slide count & structure**:
- [ ] Total slides ~55–65 (flexible based on content)
- [ ] Layer divider slides (P7) separate each of the 7 layers
- [ ] Agenda slide (P22) appears as slide 2
- [ ] Source / Methodology slide (P23) appears before any appendix
- [ ] No slides created from scratch

Fix any issues, then re-verify.

---

## Delivery

Save the final `.pptx` to the user's workspace folder. Provide a direct link. Mention:
- Slide count
- Layers covered
- Patterns used (which structural patterns anchor each layer)
- Storyline thesis (the deck's governing action title)