# Slide XML Templates (v2 — Consultancy Grade)

This file contains reusable XML templates for VNF slide components. Load this file when building slide XML.

**v2 changes**:
- All templates now use **`Calibri`** (not Montserrat) — font reconciliation enforced.
- New components: Action Title, Kicker, Source Line, Takeaway Box, Harvey Ball cell, Heat Map cell, Roadmap bar, KPI Scorecard tile, Pyramid level, Driver Tree node, Three-Horizon panel, Ecosystem center node, Waterfall step, Maturity radar shell, Build-stage tile.
- Existing v1 templates (3-col card, 2-col card, table, layer divider, slide title, lead text, tagline) preserved with Calibri fix.

**⚠️ CRITICAL REMINDER**: All new content slides MUST apply the **"Content" layout** from the slide master. The layout provides separator + footer. **DO NOT manually create separators or footers.**

---

## Template Usage

1. Apply "Content" layout (every new slide)
2. Copy template XML for components
3. Replace `[PLACEHOLDER]` values
4. Use **Calibri** for all text — `<a:latin typeface="Calibri"/>`
5. Increment shape IDs uniquely (formula: `base_id = (slide_number - 1) * 100 + 1`)
6. Adjust positions per pattern coordinates in `slide_patterns.md`

---

# PART A — Slide Structure Components (Updated)

## Title Element (Short Form)

```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="1" name="Title"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="230400" y="0"/><a:ext cx="8683200" cy="720000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="2000" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[SLIDE_TITLE]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

## Kicker / Eyebrow (DEPRECATED in v2.2)

The kicker (small UPPERCASE label above the action title, e.g., `LAYER 3 · VALUE CHAIN`) was introduced in v2.0 but **removed from the default zone model in v2.2**. It produced an extra textbox at the top of every slide that pushed the title down and added visual noise across a 60-slide deck. The master's footer already shows the section context (left-aligned section label).

**Do NOT add a kicker by default.** If the user explicitly requests one for a specific slide (e.g., a layer-opener), the legacy XML is preserved below for reference, but verify it doesn't conflict with the master:

```xml
<!-- LEGACY — only use if user explicitly requests a kicker on a specific slide.
     Default behaviour: do not include this on any slide. -->
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="2" name="Kicker"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="230400" y="144000"/><a:ext cx="8683200" cy="252000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="t" lIns="0" tIns="0" rIns="0" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" spc="200" dirty="0">
        <a:solidFill><a:srgbClr val="953735"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[KICKER_TEXT]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

If a kicker is added, the action title must shift down to y=432000 to make room. **For the v2.2 default (no kicker), action title sits at y=0.**

## Action Title (Updated v2.2 — sits at top, single line)

A descriptive headline that states the conclusion. Sits at the top of the slide (y=0). **Single line only.**

**Length rules (v2.2 — strict)**:
- ≤80 characters → 24pt single line (default)
- 80–100 characters → drop to 20pt single line
- >100 characters → rewrite the title shorter (a title that long usually means the finding hasn't been crystallized)
- **NEVER let the title wrap to 2 lines.** The master's underline sits at a fixed y; a wrapped title crosses it. Shorten or shrink, don't wrap.

```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="3" name="ActionTitle"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="230400" y="0"/><a:ext cx="8683200" cy="1080000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="0" tIns="0" rIns="0" bIns="0"><a:noAutofit/></a:bodyPr>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="2400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[ACTION_TITLE]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Example `[ACTION_TITLE]`: `APAC demand will outpace global growth 2.4× through 2030`

The master's "Content" layout draws the underline beneath this. **Agent must NOT draw any horizontal line.** If a generated slide shows two horizontal lines, the agent has incorrectly added one — remove it.

## Title Underline Separator (REMOVED in v2.2 — do not draw)

The manual title underline introduced in v2.1 has been **removed**. It produced double lines because most agents drew it without successfully suppressing the master's existing underline. The double line was the v2.1 regression seen in generated decks.

**Rule**: never draw a horizontal line under the title. Trust the master. If your title would cross the master's line, the title is too long — shorten it. There is no "manual separator" component in v2.2.

If you encounter legacy v2.1 XML that contains a `TitleUnderline` `cxnSp`, delete it.

## Section Label

```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="4" name="SectionLabel"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="800000"/><a:ext cx="8229600" cy="304800"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="t"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="900" b="1" spc="200" dirty="0">
        <a:solidFill><a:srgbClr val="888888"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>LAYER [N] · [LAYER_NAME] · FIELD [N] — [FIELD_TOPIC]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

## Lead Text Element

```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="5" name="LeadText"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="914400"/><a:ext cx="8229600" cy="508000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="t"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1400" dirty="0">
        <a:solidFill><a:srgbClr val="595959"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[LEAD_TEXT]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

## Source Line (Updated v2.2 — moved ABOVE tagline)

Required on any slide using third-party data. **Sits ABOVE the tagline**, between content and tagline. Position fixed: y=5436000 (15.1cm), cy=180000 (0.5cm).

**Why the move (v2.1 → v2.2)**: the previous position (y=6336000, below the tagline) crossed the master's footer separator at ~17.8cm. Moving the source above the tagline puts it well clear of any master decorations.

```xml
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="6" name="SourceLine"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="230400" y="5436000"/><a:ext cx="6048000" cy="180000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="b" lIns="0" tIns="0" rIns="0" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="900" i="1" dirty="0">
        <a:solidFill><a:srgbClr val="888888"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>Source: [SOURCE_LIST]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Example `[SOURCE_LIST]`: `Statista 2025; FAO Aquaculture Report 2024; team analysis`

## Tagline / Takeaway Box (Updated v2.1 — rounded corners, repositioned, prefix policy)

⚠️ Agent MUST create this. NOT the footer.

**Changes from v2**:
- Position moved up to y=5832000 (16.2cm) so it doesn't overlap source line or footer.
- Box uses `roundRect` with `adj=4500` (matches card corner radius) instead of sharp `rect`.
- `[TAGLINE_TEXT]` should be a clean takeaway sentence — **no literal "SO WHAT" prefix by default**. See "Prefix policy" below.

```xml
<!-- Tagline Background Box (rounded) -->
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="400" name="TaglineBox"/>
    <p:cNvSpPr/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="5832000"/><a:ext cx="8229600" cy="432000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 4500"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="D6F1FC"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="0070C0"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Tagline Text -->
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="401" name="TaglineText"/>
    <p:cNvSpPr txBox="1"/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="571200" y="5904000"/><a:ext cx="8001600" cy="288000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="114300" tIns="0" rIns="114300" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1300" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[TAGLINE_TEXT]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

### Prefix Policy (NEW v2.1)

The Zone 4 takeaway is **not** automatically prefixed with "SO WHAT". Choose one of three styles per slide:

| Style | When to use | Example `[TAGLINE_TEXT]` |
|-------|-------------|--------------------------|
| **A. No prefix (default)** | Most slides — analytical findings, summaries, observations | `Locking supplier contracts before Q3 is now the highest-leverage cost action.` |
| **B. Arrow prefix** | When the takeaway is the next-step recommendation, but you want a softer cue than "SO WHAT" | `→  Lock supplier contracts before Q3 to avoid 12pp EBITDA miss.` |
| **C. "SO WHAT" prefix** | Reserve for headline action / decision slides where the audience must be told this is the call-to-action — typically Pattern 10 (Exec summary), Pattern 17 (Roadmap closer), or layer-closing recommendations | `SO WHAT  Pharma USP/EP is the single highest-value pivot — if VNF can clear the GMP regulatory hurdle, payback transforms.` |

**Anti-pattern**: Putting "SO WHAT" on every single slide. Across a 60-slide deck this becomes corporate filler and the audience tunes it out. Keep the prefix earned.

If using style C, format the prefix as small caps with two-space gap:
```xml
<a:r><a:rPr lang="en-US" sz="1300" b="1" spc="100" dirty="0">
  <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr><a:t>SO WHAT  </a:t></a:r>
<a:r><a:rPr lang="en-US" sz="1300" b="1" dirty="0">
  <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr><a:t>[TAKEAWAY_SENTENCE]</a:t></a:r>
```

---

# PART B — V1 Patterns (Reproduced with Calibri)

## 3-Column Card (Pattern 1) — Calibri Reconciled

**Left Column Card** (replicate for center/right by shifting `x` per coordinate table):

```xml
<!-- Card Body -->
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="101" name="Card 101"/>
    <p:cNvSpPr/>
    <p:nvPr/>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="1651000"/><a:ext cx="2641600" cy="3429000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 4500"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="F7F8FA"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="E5E7EB"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr wrap="square" anchor="t"/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Accent Bar -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="102" name="Bar 102"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="1651000"/><a:ext cx="2641600" cy="63500"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="[ACCENT_COLOR]"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Card Text -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="103" name="CardTxt 103"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="660400" y="1879600"/><a:ext cx="2235200" cy="3048000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:noAutofit/></a:bodyPr>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" spc="200" dirty="0">
        <a:solidFill><a:srgbClr val="[ACCENT_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[CATEGORY]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr algn="l"><a:spcBef><a:spcPts val="600"/></a:spcBef></a:pPr>
      <a:r><a:rPr lang="en-US" sz="3200" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[STAT]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" spc="100" dirty="0">
        <a:solidFill><a:srgbClr val="595959"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[LABEL]</a:t></a:r>
    </a:p>
    <a:p><a:pPr algn="l"><a:spcBef><a:spcPts val="800"/></a:spcBef><a:buNone/></a:pPr><a:endParaRPr lang="en-US" sz="400"/></a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="[ACCENT_COLOR]"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1100" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BULLET_1]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="[ACCENT_COLOR]"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1100" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BULLET_2]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

(2-column variant uses card cx=4038600, text cx=3632200, x positions per pattern 2 table.)

## Layer Divider (Pattern 7) — Calibri Reconciled

```xml
<!-- Background -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="301" name="Background"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="0" y="0"/><a:ext cx="9144000" cy="6858000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
</p:sp>

<!-- Layer Title -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="302" name="LayerTitle"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="2743200"/><a:ext cx="8229600" cy="1371600"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="4000" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>LAYER [N]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr algn="ctr"><a:spcBef><a:spcPts val="400"/></a:spcBef></a:pPr>
      <a:r><a:rPr lang="en-US" sz="2800" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[LAYER_NAME]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

## Data Table (Pattern 3) — Calibri Reconciled

(All `<a:latin typeface="Montserrat"/>` references in the v1 table template should be replaced with `<a:latin typeface="Calibri"/>`. Coordinates and structure are unchanged.)

---

# PART C — Consultancy-Grade Components (NEW)

## Pillar Card (Pattern 10 — Action-Title Pillars)

A vertical card with a numbered badge at the top, heading, and bullet list. Replicate 3× across columns.

```xml
<!-- Pillar Card 1 (left) — copy and shift x for pillars 2 (3327400) and 3 (6197600) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="110" name="Pillar1"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="1620000"/><a:ext cx="2641600" cy="3960000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 4500"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Numbered Badge -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="111" name="PillarBadge1"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="660400" y="1764000"/><a:ext cx="432000" cy="432000"/></a:xfrm>
    <a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[N]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>

<!-- Pillar Heading + Bullets -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="112" name="PillarText1"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="660400" y="2304000"/><a:ext cx="2235200" cy="3132000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1600" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[PILLAR_HEADING]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="0070C0"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1300" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BULLET_1]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="0070C0"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1300" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BULLET_2]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="0070C0"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1300" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BULLET_3]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

## Pyramid Level Box (Pattern 11)

A reusable rounded rectangle node used at all 3 tiers. Vary fill by tier. **Top tier is wider than middle/bottom tiers** so the governing-thought sentence fits — see Pattern 11 for exact dimensions.

```xml
<!-- Pyramid Tier — fill: 002060 (top), 0070C0 (middle), FFFFFF (bottom with navy border) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="120" name="PyramidNode"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="[CX]" cy="[CY]"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 6000"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="[TIER_FILL]"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="002060"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="91440" tIns="45720" rIns="91440" bIns="45720"><a:normAutofit fontScale="100000" lnSpcReduction="0"/></a:bodyPr>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="[SIZE]" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[TEXT_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[NODE_TEXT]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Tier matrix (v2.2):
| Tier | x / cx | y / cy | Fill | Text | Size |
|------|--------|--------|------|------|------|
| Top (governing thought) | 1828800 / 5486400 | 1224000 / 1080000 | `002060` | `FFFFFF` | 1400 |
| Middle (3 args, left/center/right) | 457200 / 3327400 / 6197600 — each cx=2641600 | 2592000 / 720000 | `0070C0` | `FFFFFF` | 1200 |
| Bottom (evidence list) | same x triple — each cx=2641600 | 3456000 / 1944000 | `FFFFFF` | `2C2C2C` | 1100 |

`<a:normAutofit/>` is included in the body so PowerPoint auto-shrinks text if it's too long for the box (defensive: shouldn't trigger if you size correctly, but prevents overflow).

### Pyramid Connectors (CRITICAL — fixes wrong-direction bug)

The 3 connectors must go from the **bottom-center of the TOP box** to the **top-center of EACH middle box**. Common mistake: connecting them in the wrong direction (e.g., from middle box to top box, or from one lower box to another). Use the explicit anchor IDs and `flipH` flags below.

For the standard top-tier (x=1828800, cx=5486400, y=1224000, cy=1080000), the bottom-center is at **(4572000, 2304000)**. For middle-tier boxes at y=2592000, the top-center of each is:
- Left:   (1778000, 2592000)
- Middle: (4648200, 2592000)
- Right:  (7518400, 2592000)

```xml
<!-- Connector 1: top box bottom-center → lower-LEFT box top-center.
     Goes diagonal down-LEFT, so flipH="1" is required. -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="601" name="PyramidConn1"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>
      <a:endCxn id="[LOWER_1_ID]" idx="0"/>
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm flipH="1">
      <a:off x="1778000" y="2304000"/>
      <a:ext cx="2794000" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Connector 2: top → lower-MIDDLE, near-vertical -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="602" name="PyramidConn2"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>
      <a:endCxn id="[LOWER_2_ID]" idx="0"/>
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="4572000" y="2304000"/>
      <a:ext cx="76200" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Connector 3: top → lower-RIGHT, diagonal down-right (no flip) -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="603" name="PyramidConn3"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>
      <a:endCxn id="[LOWER_3_ID]" idx="0"/>
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="4572000" y="2304000"/>
      <a:ext cx="2946400" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>
```

**General rule for any connector from point A to point B**:
```
off.x = min(A.x, B.x)
off.y = min(A.y, B.y)
ext.cx = |B.x - A.x|
ext.cy = |B.y - A.y|
flipH = "1" if B.x < A.x   (going right→left)
flipV = "1" if B.y < A.y   (going bottom→top)
```

**`stCxn` and `endCxn` `idx` values for rectangles**: 0 = top edge center, 1 = right edge center, 2 = bottom edge center, 3 = left edge center. Always anchor parent → child as `idx=2` (bottom of parent) → `idx=0` (top of child) for top-down pyramids.

**Verification check**: after generating the slide, eyeball the connectors. All three should originate at the same point (bottom-center of top box) and fan to the three lower boxes. If they all converge somewhere else, you anchored to the wrong shapes — re-check `stCxn`/`endCxn` IDs.

## Waterfall Bar (Pattern 12)

Each step is a rectangle with delta label on top and step name below.

```xml
<!-- Waterfall step bar -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="130" name="WfStep"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="1100000" cy="[CY]"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="[BAR_COLOR]"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Delta label (above bar) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="131" name="WfDelta"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y_LABEL]"/><a:ext cx="1100000" cy="252000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="b" lIns="0" tIns="0" rIns="0" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1200" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[+/-VALUE]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Bar color rules:
- Anchor (start/end): `002060` (Navy đậm)
- Positive delta: `2E7D32` (Success)
- Negative delta: `C00000` (Danger)

Connector dashed lines between bar tops: use `cxnSp` with `prstDash val="dash"` and color `D9D9D9`.

## BCG 2×2 Plot Frame + Bubble (Pattern 13)

```xml
<!-- Plot frame (outer rect) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="140" name="2x2Frame"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="1300000" y="1620000"/><a:ext cx="6800000" cy="4200000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
    <a:ln w="12700"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Vertical mid-line -->
<p:cxnSp>
  <p:nvCxnSpPr><p:cNvPr id="141" name="VLine"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm><a:off x="4700000" y="1620000"/><a:ext cx="0" cy="4200000"/></a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Horizontal mid-line -->
<p:cxnSp>
  <p:nvCxnSpPr><p:cNvPr id="142" name="HLine"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm><a:off x="1300000" y="3720000"/><a:ext cx="6800000" cy="0"/></a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Bubble (option plotted) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="143" name="Bubble"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[BUBBLE_X]" y="[BUBBLE_Y]"/><a:ext cx="[BUBBLE_D]" cy="[BUBBLE_D]"/></a:xfrm>
    <a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="0070C0"><a:alpha val="65000"/></a:srgbClr></a:solidFill>
    <a:ln w="12700"><a:solidFill><a:srgbClr val="002060"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p><a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[LABEL]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Diameter `[BUBBLE_D]`: 360000 (small), 504000 (medium), 720000 (large). Use diameter to encode a third variable (e.g., revenue size).

## Harvey Ball Cell (Pattern 14)

A single text-box cell containing one Harvey Ball glyph centered. Replicate per criterion × option grid cell.

```xml
<p:sp>
  <p:nvSpPr><p:cNvPr id="150" name="HarveyCell"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="1382400" cy="432000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="2000" dirty="0">
        <a:solidFill><a:srgbClr val="[STATUS_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[GLYPH]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

`[GLYPH]` ∈ { ○ ◔ ◑ ◕ ● }. `[STATUS_COLOR]`:
- ● ◕ → `2E7D32` (success) when polarity is positive; else `002060`
- ◑ → `C97A00` (warning)
- ◔ ○ → `C00000` (danger) when polarity is negative; else `888888`

## Heat Map Cell (Pattern 15)

```xml
<p:sp>
  <p:nvSpPr><p:cNvPr id="160" name="HeatCell"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="1300000" cy="840000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="[RAMP_STEP]"/></a:solidFill>
    <a:ln w="6350"><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1100" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[CELL_TEXT_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[CELL_LABEL]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

`[RAMP_STEP]` from sequential palette: `EAF2FA / BFD8EC / 7FB1D9 / 2E7BBF / 002060`.
`[CELL_TEXT_COLOR]`: `FFFFFF` if step ≥ 3, else `002060`.

## Driver Tree Node (Pattern 16)

Reusable node with metric name, value, delta arrow.

```xml
<p:sp>
  <p:nvSpPr><p:cNvPr id="170" name="DriverNode"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="1900000" cy="720000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 6000"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="[NODE_FILL]"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="002060"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="91440" tIns="45720" rIns="91440" bIns="45720"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[TEXT_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[METRIC_NAME]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[TEXT_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[VALUE]   </a:t></a:r>
      <a:r><a:rPr lang="en-US" sz="1100" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[DELTA_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[ARROW] [DELTA]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Levels: Root `002060`/`FFFFFF`. L2 `0070C0`/`FFFFFF`. L3 `FFFFFF`/`2C2C2C`. Arrow ▲ green / ▼ red / ◆ neutral.

Branch lines between parent and child: thin gray L-shaped connectors via `cxnSp` (use `prstGeom prst="bentConnector3"`).

## Roadmap Bar (Pattern 17)

```xml
<!-- Bar -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="180" name="RoadmapBar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[BAR_X]" y="[BAR_Y]"/><a:ext cx="[BAR_CX]" cy="432000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 25000"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="[WORKSTREAM_COLOR]"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="91440" tIns="0" rIns="91440" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1000" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[BAR_LABEL]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>

<!-- Milestone Diamond -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="181" name="Milestone"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[MS_X]" y="[MS_Y]"/><a:ext cx="252000" cy="252000"/></a:xfrm>
    <a:prstGeom prst="diamond"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="E6AF00"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="002060"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>
```

`[WORKSTREAM_COLOR]` rotates through the categorical palette (`002060`, `0070C0`, `598C48`, `953735`).

## KPI Scorecard Tile (Pattern 21)

```xml
<!-- Tile body -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="200" name="KpiTile"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="2030200" cy="1640000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 4500"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Top status bar -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="201" name="KpiStatusBar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="2030200" cy="36000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="[STATUS_DARK]"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- KPI content text -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="202" name="KpiText"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X+114300]" y="[Y+180000]"/><a:ext cx="1801600" cy="1380000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"/>
    <a:lstStyle/>
    <!-- KPI name + status glyph -->
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1200" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[KPI_NAME]   </a:t></a:r>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[STATUS_DARK]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[GLYPH]</a:t></a:r>
    </a:p>
    <!-- Value -->
    <a:p>
      <a:pPr algn="ctr"><a:spcBef><a:spcPts val="600"/></a:spcBef></a:pPr>
      <a:r><a:rPr lang="en-US" sz="2800" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[VALUE]</a:t></a:r>
    </a:p>
    <!-- Target / vs prior -->
    <a:p>
      <a:pPr algn="ctr"><a:spcBef><a:spcPts val="200"/></a:spcBef></a:pPr>
      <a:r><a:rPr lang="en-US" sz="1000" dirty="0">
        <a:solidFill><a:srgbClr val="888888"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>Target [TARGET]   |   vs prior [DELTA]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

`[STATUS_DARK]` ∈ { `2E7D32`, `C97A00`, `C00000`, `595959` }. `[GLYPH]` ∈ { ▲, ▼, ◆ }.

## Three-Horizon Panel (Pattern 19)

```xml
<!-- Right-side horizon panel — copy 3× with adjusted y -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="210" name="HorizonPanel"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="6000000" y="[PANEL_Y]"/><a:ext cx="2700000" cy="1300000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 4500"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
    <a:ln w="12700"><a:solidFill><a:srgbClr val="[HORIZON_COLOR]"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" lIns="91440" tIns="91440" rIns="91440" bIns="91440" anchor="t"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1100" b="1" spc="200" dirty="0">
        <a:solidFill><a:srgbClr val="[HORIZON_COLOR]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>HORIZON [N] · [TIMEFRAME]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr algn="l"><a:spcBef><a:spcPts val="300"/></a:spcBef></a:pPr>
      <a:r><a:rPr lang="en-US" sz="1300" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[HORIZON_THEME]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450"><a:spcBef><a:spcPts val="400"/></a:spcBef>
        <a:buClr><a:srgbClr val="[HORIZON_COLOR]"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1100" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[INITIATIVE_1]</a:t></a:r>
    </a:p>
    <a:p>
      <a:pPr marL="171450" indent="-171450"><a:spcBef><a:spcPts val="400"/></a:spcBef>
        <a:buClr><a:srgbClr val="[HORIZON_COLOR]"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="•"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1100" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[INITIATIVE_2]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

`[HORIZON_COLOR]`: H1 `002060`, H2 `0070C0`, H3 `953735`.

S-curves on the left can be approximated with `prstGeom prst="curvedDownArrow"` or, ideally, freeform paths. For simpler builds, use 3 horizontal arrows of differing length stacked at decreasing y.

## Ecosystem Center Node + Connector (Pattern 20)

```xml
<!-- Center node -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="220" name="EcoCenter"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="3850000" y="2700000"/><a:ext cx="1450000" cy="1450000"/></a:xfrm>
    <a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
    <a:ln w="12700"><a:solidFill><a:srgbClr val="0070C0"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[CORE_ENTITY]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>

<!-- Stakeholder satellite node -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="221" name="EcoSatellite"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="[Y]"/><a:ext cx="1300000" cy="720000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 12000"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="0070C0"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1100" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[STAKEHOLDER]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>

<!-- Connector line center → stakeholder -->
<p:cxnSp>
  <p:nvCxnSpPr><p:cNvPr id="222" name="EcoLink"/><p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X1]" y="[Y1]"/><a:ext cx="[DX]" cy="[DY]"/></a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:prstDash val="dash"/><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>
```

## Build / Sequential Stage Tile (Pattern 24)

```xml
<!-- Stage tile — vary state: focus / past / future -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="230" name="BuildStage"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="2160000"/><a:ext cx="1630000" cy="1800000"/></a:xfrm>
    <a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val 6000"/></a:avLst></a:prstGeom>
    <a:solidFill><a:srgbClr val="[STAGE_FILL]"/></a:solidFill>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="[STAGE_BORDER]"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="91440" tIns="45720" rIns="91440" bIns="45720"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="[STAGE_TEXT]"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[STAGE_NAME]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

State matrix:
| State | Fill | Border | Text |
|-------|------|--------|------|
| Focus (current) | `002060` | `002060` | `FFFFFF` |
| Past (revealed) | `F2F2F2` | `D9D9D9` | `888888` |
| Future (outlined) | `FFFFFF` | `D9D9D9` | `D9D9D9` |

## Maturity Radar Shell (Pattern 18)

PowerPoint shape geometry can't render a true polygon radar without freeform paths. Two practical options:

**Option A — Embedded chart** (recommended): insert a `chart.xml` with a radar chart type pointing to category and series data. This is the cleanest approach.

**Option B — Layered pentagons** (shape-only fallback):

```xml
<!-- Concentric grid pentagons (5 rings) -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="240" name="RadarRing"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X_RING]" y="[Y_RING]"/><a:ext cx="[D_RING]" cy="[D_RING]"/></a:xfrm>
    <a:prstGeom prst="pentagon"><a:avLst/></a:prstGeom>
    <a:noFill/>
    <a:ln w="6350"><a:solidFill><a:srgbClr val="D9D9D9"/></a:solidFill></a:ln>
  </p:spPr>
</p:sp>

<!-- Current / target polygon shapes layered on top using freeform paths -->
<!-- (Use embedded chart in production for accuracy) -->
```

## Agenda Row (Pattern 22)

```xml
<!-- Agenda row — replicate per item -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="250" name="AgendaRow"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="1000000" y="[Y]"/><a:ext cx="7400000" cy="600000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="[ROW_FILL]"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody>
</p:sp>

<!-- Number badge -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="251" name="AgendaNum"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="1080000" y="[Y+84000]"/><a:ext cx="432000" cy="432000"/></a:xfrm>
    <a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>
    <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
    <a:ln><a:noFill/></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="1400" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[N]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>

<!-- Item title + page indicator -->
<p:sp>
  <p:nvSpPr><p:cNvPr id="252" name="AgendaTxt"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="1620000" y="[Y]"/><a:ext cx="6700000" cy="600000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr" lIns="91440" tIns="0" rIns="91440" bIns="0"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r><a:rPr lang="en-US" sz="1600" b="[BOLD]" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[ITEM_TITLE]</a:t></a:r>
      <a:r><a:rPr lang="en-US" sz="1100" i="1" dirty="0">
        <a:solidFill><a:srgbClr val="888888"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>     p. [PAGE]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

`[ROW_FILL]`: alternate `FFFFFF` / `F5F5FF`. For a divider variant, set the focused row's fill to `D6F1FC` and `[BOLD]` = `1`.

## Source / Methodology Column Header (Pattern 23)

```xml
<p:sp>
  <p:nvSpPr><p:cNvPr id="260" name="SrcMethodCol"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="[X]" y="1620000"/><a:ext cx="2641600" cy="4320000"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" lIns="91440" tIns="91440" rIns="91440" bIns="91440" anchor="t"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l">
        <a:lnSpc><a:spcPct val="115000"/></a:lnSpc>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1300" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[COLUMN_HEADER]</a:t></a:r>
    </a:p>
    <!-- Bullet list items follow -->
    <a:p>
      <a:pPr marL="171450" indent="-171450">
        <a:spcBef><a:spcPts val="600"/></a:spcBef>
        <a:buClr><a:srgbClr val="888888"/></a:buClr>
        <a:buFont typeface="Arial"/><a:buChar char="–"/>
      </a:pPr>
      <a:r><a:rPr lang="en-US" sz="1100" dirty="0">
        <a:solidFill><a:srgbClr val="2C2C2C"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[ITEM]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

Column headers: `SOURCES` / `METHODOLOGY` / `ASSUMPTIONS & CAVEATS`.

---

## Cover Slide Title (Updated — Calibri)

```xml
<p:sp>
  <p:nvSpPr><p:cNvPr id="1" name="CoverTitle"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="457200" y="2743200"/><a:ext cx="8229600" cy="1371600"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:noFill/>
  </p:spPr>
  <p:txBody>
    <a:bodyPr wrap="square" anchor="ctr"/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="ctr"/>
      <a:r><a:rPr lang="en-US" sz="4800" b="1" dirty="0">
        <a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>
        <a:latin typeface="Calibri"/>
      </a:rPr><a:t>[REPORT_TITLE]</a:t></a:r>
    </a:p>
  </p:txBody>
</p:sp>
```

---

## Placeholder Reference (Expanded)

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `[ACCENT_COLOR]` | Accent hex | `953735`, `0070C0`, `2E7D32` |
| `[KICKER_TEXT]` | Eyebrow text (UPPERCASE) | `MARKET OUTLOOK · ASIA-PACIFIC` |
| `[ACTION_TITLE]` | Descriptive headline | `Asia-Pacific demand will outpace global growth by 2.4× through 2030` |
| `[CATEGORY]` | Card category | `EFFICACY`, `MARKET SIZE` |
| `[STAT]` | Hero stat | `42%`, `$2.5B`, `2028` |
| `[LABEL]` | Stat label | `METHANE REDUCTION` |
| `[BULLET_N]` | Bullet text | `Supporting detail` |
| `[PILLAR_HEADING]` | Pillar title in Pattern 10 | `Regulatory tailwinds` |
| `[N]` | Index number | `1`, `2`, `3` |
| `[NODE_TEXT]` | Pyramid/driver-tree node text | `Revenue declined 12% YoY` |
| `[GLYPH]` | Harvey Ball / status | `●`, `◑`, `▲` |
| `[STATUS_COLOR]` / `[STATUS_DARK]` | Semantic status | `2E7D32`, `C97A00`, `C00000` |
| `[RAMP_STEP]` | Heat-map fill | `EAF2FA` … `002060` |
| `[CELL_TEXT_COLOR]` | Heat-map text | `FFFFFF` or `002060` |
| `[METRIC_NAME]` | Driver/KPI name | `Margin %` |
| `[VALUE]` | KPI/driver value | `$4.2M` |
| `[ARROW]` / `[DELTA]` | Trend pair | `▼ -8%`, `▲ +2%` |
| `[WORKSTREAM_COLOR]` | Roadmap bar color | from categorical palette |
| `[MS_X]`, `[MS_Y]` | Milestone diamond x/y | EMU coords |
| `[BAR_X]`, `[BAR_CX]` | Roadmap bar pos/width | EMU coords |
| `[KPI_NAME]` | Tile metric name | `Revenue` |
| `[TARGET]` | KPI target | `$4.0M` |
| `[HORIZON_COLOR]` / `[HORIZON_THEME]` / `[INITIATIVE_N]` | Three-horizon panel | per pattern 19 |
| `[CORE_ENTITY]` / `[STAKEHOLDER]` | Ecosystem nodes | `VNF` / `Regulator` |
| `[STAGE_NAME]` / `[STAGE_FILL]` / `[STAGE_BORDER]` / `[STAGE_TEXT]` | Build tile state | per pattern 24 state matrix |
| `[ROW_FILL]` / `[ITEM_TITLE]` / `[PAGE]` | Agenda row | per pattern 22 |
| `[COLUMN_HEADER]` / `[ITEM]` | Source/method column | per pattern 23 |
| `[SLIDE_TITLE]` | Short-form title | `Key Findings Overview` |
| `[LAYER_N]` / `[LAYER_NAME]` | Layer divider | `1`, `SCIENCE LAYER` |
| `[FIELD_N]` / `[FIELD_TOPIC]` | Field meta | `1`, `METHANE FORMATION` |
| `[LEAD_TEXT]` | Lead paragraph | `This section explores...` |
| `[TAGLINE_TEXT]` | Zone-4 takeaway | `So what: shift focus to APAC` |
| `[SOURCE_LIST]` | Source line text | `Statista 2025; team analysis` |
| `[REPORT_TITLE]` | Cover title | `Methane Emission Reduction` |
| `[HEADER_N]` / `[DATA_N]` | Table cells | `Technology` / `30% reduction` |

---

## Shape ID Management

Each shape needs a unique ID within the presentation.

ID ranges by slide: `base_id = (slide_number - 1) * 100 + 1`. e.g. Slide 5 starts at ID 401.

Within a slide, components have suggested ID offsets:
- 0–9: title / kicker / lead / source / tagline
- 10–29: charts, tables, primary visual
- 30–59: cards / pillars / nodes
- 60–79: connectors / lines / arrows
- 80–99: decorations, footnotes