# Slide Deck Builder — Detailed Guide (v2 — Consultancy Grade)

## Design Reference

The target look is a **VNF consultancy-grade deck** modeled on BCG / McKinsey / Bain / Roland Berger conventions, executed in the VNF brand system. Reference file: `POL022_Methane emission reduction in ruminants_Slide_v1.pptx`. Every slide must match VNF's design language (color, card anatomy, typography) AND apply the consultancy storyline conventions described below.

**v2 changes**:
- Adds 15 consultancy patterns (10–24) on top of the original 9.
- Reconciles font: **Calibri only** (templates updated; legacy Montserrat references removed).
- Adds 5-zone slide structure (Kicker · Title · Content · Source · Tagline · Footer).
- Adds storyline guidance (action titles, MECE, pyramid, "so what" takeaways).
- Adds new QA checks for source citations and action-title quality.

---

## Multi-File Architecture

```
references/
├── slide_guide.md              # This file — overview, workflow, storyline, QA
├── slide_specs.md              # Dimensions, colors, typography, semantic tokens
├── slide_patterns.md           # 24 layout patterns with coordinates
└── slide_templates.md          # Reusable XML component templates
```

| Benefit | Description |
|---------|-------------|
| Context efficiency | Load only what's needed for current task |
| Faster lookups | Specs / patterns / templates each in their own file |
| Modular updates | Update patterns without re-touching specs |
| Parallel reference | Multiple agents can reference different files |

---

## The Consultancy Storyline (NEW — Read This First)

Every consultancy-grade deck follows a **storyline** — not a topic dump. Three principles drive all 24 patterns:

### 1. Action Titles, Not Topic Titles

Replace topic titles ("Market Analysis") with **descriptive sentences that state the conclusion** ("Asia-Pacific demand will outpace global growth by 2.4× through 2030"). The CEO should be able to read only the titles in sequence and reconstruct your argument.

- Use 24pt bold Navy đậm Calibri (not 20pt) for action titles.
- Pair with a Kicker (10pt UPPERCASE Đỏ chính) to show category context.
- See Pattern 10 (Executive Summary) for the canonical action-title slide.

### 2. Pyramid Principle (Minto)

Every slide answers a question. Lead with the answer (the governing thought), then support it with 3 mutually exclusive, collectively exhaustive (MECE) arguments, each with evidence.

- The deck overall is a pyramid. So is each slide.
- The action title = governing thought of that slide.
- The pillars / cards / bars / cells = the supporting MECE arguments.
- Use Pattern 11 (Pyramid) for argument slides.

### 3. "So What" Takeaways

Every analytical slide ends with a **takeaway** in Zone 4 — a blue box with the implication for the reader, not a restatement of the title.

- Bad: "Margins are down 8%."
- Good: "If we don't lock supplier contracts before Q3, EBITDA will miss by 12pp."
- The agent MUST create the Zone 4 tagline. The slide master does NOT do this.

### Storyline Sequence per Layer

A 12-slide layer should typically read:

1. **Pattern 22 (Agenda highlight)** — anchor reader in the deck
2. **Pattern 10 (Action title + 3 pillars)** — state the layer's thesis
3–6. **Patterns 1, 12, 14, 16** — evidence (cards, waterfall, Harvey Balls, driver tree)
7–8. **Patterns 13, 6** — strategic positioning (BCG 2×2 + SWOT)
9. **Pattern 17 (Roadmap)** — what we'll do
10. **Pattern 21 (KPI scorecard)** — how we'll measure
11. **Pattern 11 (Pyramid)** — argument summary
12. **Pattern 7 (Layer divider)** — transition

---

## Slide Building Workflow

### Phase 1: Setup

1. Read `outline-master.md` for overview, then specific layer files.
2. Copy + unpack the VNF template.
3. Plan the storyline: assign each slide a pattern AND draft its action title before building.

### Phase 2: Build by Layer

For each `outline-layer-N.md`:
  1. Read `slide_specs.md` (dimensions, colors, typography, semantic tokens)
  2. Read `slide_patterns.md` (pick patterns for the layer's storyline)
  3. Read `slide_templates.md` (XML for the chosen patterns)
  4. Build slides
  5. Run layer QA

### Phase 3: Integration

1. Combine all slides into a single presentation.
2. Update slide relationships in `presentation.xml.rels` and `presentation.xml`.
3. Add layer dividers between sections.
4. Run final QA.

### Phase 4: Repack and Deliver

1. Repack to PPTX.
2. Verify slide count (~55–65 slides).
3. Final visual QA.

---

## File Reference Guide

| Task | File to Load |
|------|--------------|
| Setting up dimensions, colors, fonts, semantic tokens | `slide_specs.md` |
| Choosing a pattern | `slide_patterns.md` |
| Getting XML for a component | `slide_templates.md` |
| Workflow / storyline guidance | `slide_guide.md` (this file) |

### Quick Reference

```
DIMENSIONS:    25.40 × 19.05 cm (4:3, 9144000 × 6858000 EMU)
FONT:          Calibri ONLY
TITLES:        Action 24pt / Short 20pt / Cover 48pt — bold Navy đậm 002060
KICKER:        10pt bold UPPERCASE Đỏ chính 953735
BODY:          13pt Calibri Body 2C2C2C
SOURCE:        9pt italic Gray 888888
TAKEAWAY:      13pt bold Navy đậm on D6F1FC blue box

PRIMARY COLORS:
  Navy đậm:     002060 — Titles
  Đỏ chính:     953735 — PRIMARY emphasis
  Đỏ critical:  C00000 — Warnings
  Xanh sáng:    0070C0 — Data series 1
  Xanh da trời: D6F1FC — Takeaway box

SEMANTIC STATUS (NEW):
  Success: 2E7D32 / E8F5E9
  Warning: C97A00 / FFF4E0
  Danger:  C00000 / FCE4E4
  Info:    0070C0 / D6F1FC
  Neutral: 595959 / F2F2F2
```

---

## Building Process (MANDATORY 3-STEP PROCESS)

### ⚠️ CRITICAL: Strict Process Enforcement

**Template Location**: `assets/vnf_slide_template.pptx`

### STEP 1: Clone the Template

```bash
cp assets/vnf_slide_template.pptx working_directory/new_slidedeck.pptx
```

- ✅ Clone first
- ❌ NEVER create from scratch

### STEP 2: Use the Cover Page

Keep slide 1 from the cloned template; replace ONLY the title text. Preserve VNF logo, brand logos, contact block, "Confidential" labels, background, and layout.

### STEP 3: Append Subsequent Slides

Each new slide MUST apply the **"Content" layout** from the slide master (provides separator + footer automatically). Build content per VNF style guidelines and use the storyline patterns.

```bash
python scripts/office/unpack.py "new_slidedeck.pptx" unpacked/
# build new slide XMLs in unpacked/ppt/slides/, update rels and presentation.xml
python scripts/clean.py unpacked/
python scripts/office/pack.py unpacked/ output.pptx --original "assets/vnf_slide_template.pptx"
```

---

## Layer Processing Order

| Order | Layer | Outline File | Suggested Storyline |
|-------|-------|--------------|---------------------|
| 1 | Cover | — | Template cover, title only |
| 2 | Agenda | — | Pattern 22 |
| 3 | Layer 1 — Science | outline-layer-1.md | Divider → Action title → Evidence → Pyramid → Divider |
| 4 | Layer 2 — Technology | outline-layer-2.md | Divider → BCG 2×2 → Harvey Balls → Driver tree → Pyramid |
| 5 | Layer 3 — Industrial | outline-layer-3.md | Divider → Roadmap → Waterfall → KPI scorecard |
| 6 | Layer 4 — Market | outline-layer-4.md | Divider → Heat map → Bar chart → Ecosystem map |
| 7 | Layer 5 — Strategic | outline-layer-5.md | Divider → Three horizons → SWOT → Maturity radar |
| 8 | Layer 6 — Strategic Architecture | outline-layer-5.md | Divider → Pyramid → Build sequence |
| 9 | Layer 7 — Applied Strategy | outline-layer-5.md | Divider → Roadmap → KPI scorecard → Closing pyramid |
| 10 | Source / Methodology | — | Pattern 23 |

Insert **Pattern 7 (Layer divider)** between every layer. Slide counts depend on content depth.

---

## Quality Checklist

### Per-Layer QA

Before moving to the next layer, verify:

- [ ] All slides apply "Content" layout from slide master
- [ ] All text is Calibri (no Montserrat / no other fonts)
- [ ] Colors match VNF 15-color palette + semantic tokens
- [ ] Each slide has at least ONE visual (not text-only)
- [ ] Each insight slide uses an **action title** (descriptive sentence, not a topic)
- [ ] Each insight slide has a **kicker** (UPPERCASE category context)
- [ ] Slide titles use 20pt (short) or 24pt (action) bold Navy đậm `002060`
- [ ] Body text is 13pt Calibri
- [ ] Taglines (Zone 4) created where the outline specifies a "Field Tagline" — every analytical slide has a "so what" takeaway
- [ ] **Source line (Zone 3) created on any slide using third-party data, market sizes, or charts**
- [ ] Storyline coherence: skim the action titles in sequence — they should reconstruct the layer's argument
- [ ] No two consecutive slides use the same pattern
- [ ] Layer includes ≥1 structural pattern (10, 11, 12, 13, 16, 17, or 19) and ≥3 evidence patterns

### Final QA

Before delivering, verify:

- [ ] STEP 1 verified: cloned from `assets/vnf_slide_template.pptx`
- [ ] STEP 2 verified: cover slide kept, only title replaced
- [ ] STEP 3 verified: all content slides use "Content" layout
- [ ] Cover elements preserved (logos, contact block, confidentiality marks)
- [ ] Cover title 48pt bold white on navy
- [ ] All content slide titles correct size + Navy đậm
- [ ] All body text 13pt Calibri
- [ ] Taglines (Zone 4) on all analytical slides
- [ ] Source lines (Zone 3) on all data-driven slides
- [ ] Layer dividers (Pattern 7) separate each layer
- [ ] Agenda (Pattern 22) appears as slide 2
- [ ] Source / Methodology (Pattern 23) appears as final non-appendix slide
- [ ] Aspect ratio is 4:3 (25.40 × 19.05 cm)
- [ ] Slide master not modified
- [ ] Page numbers continuous, starting from slide 2

### Storyline QA

- [ ] Action titles read as a coherent narrative end-to-end
- [ ] Each slide's takeaway answers "so what?" — not just restating the title
- [ ] Each layer follows a pyramid: governing thought → MECE arguments → evidence
- [ ] Recommendation slides use Pattern 10 or Pattern 11
- [ ] Risk / option slides use Pattern 14 or Pattern 15

### File Integrity QA (NEW v2.2 — must run before delivery)

Generated PPTX files frequently break because of duplicate XML IDs or malformed relationships. PowerPoint refuses to open a corrupt file (or opens it in "recovered" mode and silently drops content). **Every deck must pass these gates before delivery.**

#### Step 1: Validate the unpacked XML (before packing)

Run a structural check on `unpacked/` before repacking:

```bash
python scripts/validate_pptx_unpacked.py unpacked/
```

The validator must check:
- [ ] **No duplicate shape IDs within any single slide**. Each `<p:cNvPr id="N">` in a given `slideN.xml` must have a unique `N`. Use the formula `base_id = (slide_number - 1) * 100 + 1` and increment within each slide.
- [ ] **No duplicate slide rIds** in `unpacked/ppt/_rels/presentation.xml.rels`. Every `<Relationship Id="rIdN">` must have a unique `N`.
- [ ] **No duplicate `<p:sldId>` entries** in `unpacked/ppt/presentation.xml`. Each slide ID must be unique AND `≥ 256` (PowerPoint reserves IDs below 256).
- [ ] **All relationship targets exist**. Every `Target="..."` in any `_rels/*.xml.rels` file must point to a real file in the package.
- [ ] **All slides referenced in `presentation.xml` have a matching rel** in `presentation.xml.rels`.
- [ ] **Every slideN.xml has its own `_rels/slideN.xml.rels`** (even if empty). Missing rels file = corrupted slide.
- [ ] **No orphan media** — every file in `ppt/media/` is referenced from at least one slide rels.
- [ ] **Content types complete** — `[Content_Types].xml` declares every part type used in the package (slides, charts, images, embeddings).

If you don't have a validator script, here's a minimal Python one to run inline:

```python
# scripts/validate_pptx_unpacked.py
import os, re, sys
from collections import defaultdict
from xml.etree import ElementTree as ET

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'rel': 'http://schemas.openxmlformats.org/package/2006/relationships'}

def validate(unpacked):
    errors = []
    # 1. Per-slide shape ID uniqueness
    slides_dir = os.path.join(unpacked, 'ppt/slides')
    for fn in sorted(os.listdir(slides_dir)):
        if not fn.endswith('.xml'): continue
        path = os.path.join(slides_dir, fn)
        tree = ET.parse(path)
        ids = [el.get('id') for el in tree.iter() if el.tag.endswith('}cNvPr')]
        dup = [i for i in set(ids) if ids.count(i) > 1]
        if dup: errors.append(f"{fn}: duplicate cNvPr ids {dup}")
    # 2. presentation.xml.rels uniqueness
    rels_path = os.path.join(unpacked, 'ppt/_rels/presentation.xml.rels')
    rels = ET.parse(rels_path).getroot()
    rids = [r.get('Id') for r in rels]
    dup = [i for i in set(rids) if rids.count(i) > 1]
    if dup: errors.append(f"presentation.xml.rels: duplicate rIds {dup}")
    # 3. presentation.xml sldId uniqueness + ≥256
    pres = ET.parse(os.path.join(unpacked, 'ppt/presentation.xml')).getroot()
    sld_ids = [s.get('id') for s in pres.iter('{%s}sldId' % NS['p'])]
    dup = [i for i in set(sld_ids) if sld_ids.count(i) > 1]
    if dup: errors.append(f"presentation.xml: duplicate sldId {dup}")
    bad = [i for i in sld_ids if int(i) < 256]
    if bad: errors.append(f"presentation.xml: sldId < 256 not allowed {bad}")
    # 4. Relationship targets exist
    for root, _, files in os.walk(unpacked):
        for fn in files:
            if not fn.endswith('.rels'): continue
            path = os.path.join(root, fn)
            base = os.path.dirname(os.path.dirname(path)) if root.endswith('_rels') else os.path.dirname(path)
            tree = ET.parse(path).getroot()
            for r in tree:
                tgt = r.get('Target')
                if tgt and not tgt.startswith(('http', '#')):
                    resolved = os.path.normpath(os.path.join(base, tgt))
                    if not os.path.exists(resolved):
                        errors.append(f"{path}: missing target {tgt}")
    if errors:
        print("VALIDATION FAILED:")
        for e in errors: print(f"  - {e}")
        sys.exit(1)
    print("OK")

if __name__ == '__main__':
    validate(sys.argv[1])
```

#### Step 2: Verify the packed file actually opens

After packing, run TWO independent open-tests. If either fails, the file is corrupt — fix the underlying XML, don't ship it.

```bash
# Test A — python-pptx parse (catches most XML structure issues)
python -c "from pptx import Presentation; p = Presentation('output.pptx'); print(f'OK: {len(p.slides)} slides')"

# Test B — LibreOffice headless conversion (catches issues python-pptx tolerates)
soffice --headless --convert-to pdf output.pptx --outdir /tmp/qa_check
test -f /tmp/qa_check/output.pdf && echo "OK: LibreOffice opened the file"
```

Both must succeed. If `python-pptx` reports a parse error, look at the line/column in the traceback and inspect that slide's XML. If `soffice` reports a hang, kill it after 60s and check for unclosed XML tags or malformed relationships.

#### Step 3: Manual visual spot-check

Even if the file opens, render the first slide of each layer to PNG and eyeball it for the layout-geometry issues from the previous QA section.

```bash
pdftoppm -jpeg -r 100 /tmp/qa_check/output.pdf /tmp/qa_check/slide
ls /tmp/qa_check/slide-*.jpg
```

Common things to spot in the rendered images:
- Title overlapping a horizontal line
- Source line crossing a footer separator
- Tagline with "SO WHAT" prefix on every slide
- Pyramid connectors converging at the wrong box
- Empty boxes (placeholder text not replaced)

### Layout Geometry QA (v2.2 — simplified)

Run these on every generated slide. Together they catch the v2.0/v2.1 regressions.

- [ ] **No double horizontal line under the title.** Only the master's underline is visible. The agent has NOT drawn any `cxnSp` named TitleUnderline. If a manual line is found, delete it.
- [ ] **Title is single-line.** Action titles are ≤80 chars at 24pt, OR 80–100 chars at 20pt. No title wraps to 2 lines.
- [ ] **No kicker textbox at the top.** No "LAYER N · TOPIC" eyebrow textbox is present. Only the action title sits in Zone 1 (y=0). (Exception: kicker present only if user explicitly requested it for that slide.)
- [ ] **Only one title shape.** Inherited title placeholder from the master layout has been removed when a custom ActionTitle was used.
- [ ] **Source line position**: y=5436000 (15.1cm), cy=180000 — sits ABOVE the tagline.
- [ ] **Tagline position**: y=5832000 (16.2cm), cy=432000. Box uses `roundRect` with `adj=4500` (rounded corners).
- [ ] **Nothing in the 17.5–18.2cm band.** That entire band belongs to the master's footer separator + footer text. Agent has placed nothing there.
- [ ] **Bottom-stack order**: Content → Source → Tagline → Footer, top to bottom, with no overlap.
- [ ] **Tagline prefix policy**: most taglines have no prefix. Where used: `→` for soft recommendations; `SO WHAT  ` only on headline action / decision slides. Never on every slide.

---

## Common Issues and Fixes

| Issue | Cause | Fix |
|-------|-------|-----|
| **Two horizontal lines under the title (double underline)** | v2.1 manual title underline was drawn AND master's underline still visible | **v2.2**: do NOT draw a manual underline. Trust the master. Delete any `cxnSp` named `TitleUnderline` from generated XML. Keep titles short enough that they don't cross the master's line. |
| **Action title wraps to 2 lines and crosses the master's underline** | Title >80 chars at 24pt | Shorten the title to ≤80 chars OR drop to 20pt single line. **Never let a title wrap to 2 lines.** |
| **Extra textbox at top of slide ("LAYER 3 · VALUE CHAIN")** | Agent added a kicker / eyebrow per v2.0/v2.1 spec | **v2.2**: remove the kicker. The master's footer already shows the section context. Move the action title to y=0. Only add a kicker if the user explicitly asks for one. |
| **Source line still overlaps a horizontal line near the footer** | Source was below tagline (v2.1 position y=6336000); master draws a separator at ~17.8cm | **v2.2**: move source ABOVE the tagline at y=5436000 (15.1cm). Bottom-stack order is now Content → Source → Tagline → Footer. |
| **Tagline overlaps source line** | Both placed in the bottom band | **v2.2**: source at 15.1cm, tagline at 16.2cm — separated by 0.6cm. They no longer share a band. |
| **Tagline box has sharp corners** | `prstGeom prst="rect"` instead of `roundRect` | Use `roundRect` with `adj=4500` to match the card-style corner radius. |
| **"SO WHAT" appears on every tagline** | Agent treated "SO WHAT" as a required prefix | It's not. Default style is no prefix. Use `→` for soft recommendations; reserve "SO WHAT  " (two-space gap) for headline action / decision slides only. See `slide_templates.md` → "Prefix Policy". |
| **Phantom title placeholder above the title** | Inherited title placeholder from layout not removed when custom ActionTitle was added | Remove the inherited `<p:sp>` block referencing `type="title"` from the master. Replace with explicit ActionTitle shape only. |
| Text too small | Wrong sz | Title 2400 (action) / 2000 (short), body 1300, kicker 1000 |
| Wrong font (Montserrat appears) | Legacy template | Replace `<a:latin typeface="Montserrat"/>` → `<a:latin typeface="Calibri"/>` |
| Action title is a topic, not a finding | Author wrote a header | Rewrite as a descriptive sentence; if you can't, you don't have a finding yet |
| Missing source line on data slide | Forgotten | Add 9pt italic Gray "Source: …" at y=6336000 |
| Tagline is a restatement | Lazy takeaway | Rewrite as the implication ("so what") |
| Card not rounded | Missing prstGeom | Use `<a:prstGeom prst="roundRect">` with `adj` value |
| Colors look off | Used non-palette hex | Use exact palette from `slide_specs.md` |
| Heat map cells unreadable | Wrong text color | Use white text on steps ≥3, navy on steps ≤2 |
| Harvey Balls invisible | Wrong glyph or color | Use ○ ◔ ◑ ◕ ●, color by status when polarity matters |
| Two consecutive cards-only slides | Pattern repetition | Insert a structural pattern (waterfall, driver tree, roadmap) |
| Slide count off | Missing dividers / agenda / source | Confirm 1 cover + 1 agenda + 7 dividers + 1 source = 10 anchor slides |

---

## Pattern-to-Storyline Map

A quick map of which pattern serves which storyline purpose:

| Storyline Purpose | Patterns |
|-------------------|----------|
| Open / orient | 22 (Agenda), 7 (Layer Divider) |
| State a finding | **10 (Exec summary)**, **11 (Pyramid)** |
| Show evidence | 1, 2, 3, 9 (Cards / Tables / Bars) |
| Decompose / explain "why" | **12 (Waterfall)**, **16 (Driver tree)** |
| Compare options | 6 (SWOT), **13 (BCG 2×2)**, **14 (Harvey Balls)**, 18 (Maturity radar) |
| Score / monitor | **15 (Heat map)**, **21 (KPI scorecard)** |
| Plan implementation | 4 (Process), **17 (Roadmap)**, **19 (Three horizons)**, **24 (Build)** |
| Map context | 5 (Icon grid), **20 (Ecosystem)** |
| Highlight a quote / definition | 8 (Quote) |
| Close / cite | **23 (Source / Method)** |

Bolded items are the new consultancy-grade additions (v2).

---

## Reference Files Summary

| File | Purpose | When to Load |
|------|---------|--------------|
| `slide_specs.md` | Dimensions, colors (incl. semantic + categorical), typography (incl. action title, kicker, source) | At start of each layer |
| `slide_patterns.md` | All 24 patterns with coordinates and visual examples | When choosing layouts |
| `slide_templates.md` | Reusable XML components (Calibri-reconciled + new consultancy components) | When building XML |
| `slide_guide.md` | Workflow, storyline principles, QA | For process guidance |

---

## Migration Notes (v1 → v2)

If you have existing decks built on v1:

1. **Find / replace** all `<a:latin typeface="Montserrat"/>` → `<a:latin typeface="Calibri"/>`. The v1 templates leaked Montserrat into the XML; v2 fixes this.
2. **Re-check titles** — convert topic titles to action titles where the slide carries an analytical finding.
3. **Add source lines** — any slide with chart, table, or quoted statistic now requires a Zone 3 source line.
4. **Add takeaways** — any analytical slide without a Zone 4 takeaway box should get one.
5. **Insert Agenda + Source slides** if missing.

The 4-zone v1 model continues to work for slides that don't need kickers, action titles, or source lines (e.g., layer dividers, quote highlights). v2 zones are additive.