# Slide Specifications (v2 — Consultancy Grade)

This file contains all design specifications for VNF slide decks. Load this file when you need exact dimensions, colors, or typography values.

**v2 changes**: Adds consultancy-grade typography (action titles, kickers, takeaway boxes, source lines), semantic status colors, categorical chart palette, Harvey Ball glyphs, and a 5-zone slide structure aligned with BCG/McKinsey/Bain conventions. Calibri is enforced as the only font (templates updated accordingly).

---

## ⚠️ CRITICAL: Mandatory 3-Step Process

**The agent MUST follow this exact process. NO EXCEPTIONS.**

**Template Location**: **`assets/vnf_slide_template.pptx`**

### STEP 1: Clone the Template

```bash
cp assets/vnf_slide_template.pptx working_directory/new_slidedeck.pptx
```

- ✅ This cloned file becomes your new slide deck
- ❌ NEVER create a presentation from scratch

### STEP 2: Use the Cover Page

Keep slide 1 (cover) and replace ONLY the title text. Preserve VNF logo, brand logos, contact block, "Confidential" labels, background, and layout structure.

### STEP 3: Append Subsequent Slides

Each new slide MUST apply the **"Content" layout** from the slide master (provides separator + 3-section footer automatically). Use Calibri only, VNF 15-color palette, 20pt bold Navy đậm #002060 for titles, 13pt Calibri for body text.

---

## Slide Dimensions (VNF 4:3 Standard)

| Property | Value | Notes |
|----------|-------|-------|
| **Aspect Ratio** | **4:3** | VNF standard |
| **Width** | **25.40 cm** | 10 inches / 9144000 EMU |
| **Height** | **19.05 cm** | 7.5 inches / 6858000 EMU |
| **Safe margin** | **1.27 cm** | All sides |
| **Grid** | **12 columns** | 1.91 cm wide each |
| **Gutter** | **0.32 cm** | Between columns |

### EMU Conversions

| Unit | EMU Value |
|------|-----------|
| 1 cm | 360000 EMU |
| 1 inch | 914400 EMU |
| 1 pt | 12700 EMU |
| 25.40 cm (width) | 9144000 EMU |
| 19.05 cm (height) | 6858000 EMU |
| 1.27 cm (margin) | 457200 EMU |
| 0.32 cm (gutter) | 115200 EMU |

### Common Positions (VNF 4:3 Layout)

| Element | x | y | cx (width) | cy (height) |
|---------|---|---|------------|-------------|
| Action Title | 230400 (0.64cm) | 0 | 8683200 | 1080000 (3.0cm) |
| Slide Title (short form) | 230400 (0.64cm) | 0 | — | 720000 (2.0cm) |
| Content area start | 457200 (1.27cm) | 1224000 (3.4cm) | — | — |
| Content area end | — | 5400000 (15.0cm) | — | — |
| Source / Footnote (Zone 3) | 230400 | 5436000 (15.1cm) | 6048000 | 180000 (0.5cm) |
| Tagline (Zone 4) | 457200 | 5832000 (16.2cm) | 8229600 | 432000 (1.2cm) |
| Footer (Zone 5, master) | — | 6552000 (18.21cm) | — | 306000 (0.85cm) |

**Bottom-stack order (top → bottom)**: Content → Source → Tagline → Footer. Source sits ABOVE the tagline (15.1–15.6cm) so it never collides with the master's footer separator (which sits ~17.8cm in most VNF masters).

**v2.2 simplifications (Kicker, Title Underline removed)**:
- The **Kicker (eyebrow text like "LAYER 3 · VALUE CHAIN")** has been **removed from the default zone model**. It produced an extra textbox at the top that pushed the title down and created visual clutter on every slide. The layer/section context is already conveyed by the master's footer (left-aligned section label) and the layer-divider slides. Use a kicker only when the user explicitly asks for one.
- The **Title Underline Separator** (manual `cxnSp`) has been **removed**. It produced double lines on slides where the master's underline was still visible. Going forward: **never draw a manual horizontal line under the title.** Trust the master's underline. To prevent the title text from crossing the master's line, **keep titles short enough to fit on one line** (see Title rules below).

---

## Color Palette (VNF Brand + Consultancy Extensions)

### Primary Navy Colors

| Role | Hex | XML | Usage |
|------|-----|-----|-------|
| Navy chính | `1F497D` | `<a:srgbClr val="1F497D"/>` | Brand identity, secondary headers |
| Navy đậm | `002060` | `<a:srgbClr val="002060"/>` | Slide titles (20pt bold), action titles |
| Navy trầm | `002F69` | `<a:srgbClr val="002F69"/>` | Navy variant, dividers |

### Emphasis Colors

| Role | Hex | XML | Usage |
|------|-----|-----|-------|
| Đỏ chính | `953735` | `<a:srgbClr val="953735"/>` | **PRIMARY emphasis** (most used) |
| Đỏ critical | `C00000` | `<a:srgbClr val="C00000"/>` | Critical emphasis, warnings |

### Functional Colors

| Role | Hex | XML | Usage |
|------|-----|-----|-------|
| Xanh da trời | `D6F1FC` | `<a:srgbClr val="D6F1FC"/>` | Info / takeaway boxes |
| Xanh sáng | `0070C0` | `<a:srgbClr val="0070C0"/>` | Icons, chart series 1, links |
| Nâu olive | `615424` | `<a:srgbClr val="615424"/>` | Earth accent |
| Nâu vàng | `A99786` | `<a:srgbClr val="A99786"/>` | Warm accent |
| Vàng hổ phách | `E6AF00` | `<a:srgbClr val="E6AF00"/>` | Rare accent, highlight ring |
| Vàng tươi | `FFFF00` | `<a:srgbClr val="FFFF00"/>` | Highlight (sparingly) |
| Xanh lá | `598C48` | `<a:srgbClr val="598C48"/>` | Ecological / positive accent |
| Cam đất | `C36518` | `<a:srgbClr val="C36518"/>` | Agricultural / warning accent |

### Text Colors

| Role | Hex | XML | Usage |
|------|-----|-----|-------|
| Body text | `2C2C2C` | `<a:srgbClr val="2C2C2C"/>` | Main body text |
| Subtle body | `595959` | `<a:srgbClr val="595959"/>` | Secondary body, captions |
| Gray | `888888` | `<a:srgbClr val="888888"/>` | Footer, captions |
| Light gray rule | `D9D9D9` | `<a:srgbClr val="D9D9D9"/>` | Dividers, table grids |
| White | `FFFFFF` | `<a:srgbClr val="FFFFFF"/>` | Text on dark backgrounds |

### Semantic Status Colors (NEW — Consultancy Extension)

For Harvey Balls, traffic-light status, heat maps, scorecards, risk matrices.

| Role | Dark / Fill | Light / Background | Usage |
|------|-------------|---------------------|-------|
| Success / On Track | `2E7D32` | `E8F5E9` | Green status, opportunity, positive variance |
| Warning / At Risk | `C97A00` | `FFF4E0` | Amber status, caution, neutral variance |
| Danger / Off Track | `C00000` | `FCE4E4` | Red status, threat, negative variance |
| Info / Note | `0070C0` | `D6F1FC` | Blue info, contextual notes |
| Neutral | `595959` | `F2F2F2` | Inactive, baseline, "not applicable" |

**Rule**: Always pair a dark fill with its matching light background. Never mix families (e.g., red dark + amber light).

### Categorical Chart Palette (NEW — for series colors)

Use this 8-color qualitative palette for charts with multiple series. Order matters — start at series 1 and work down.

| # | Role | Hex |
|---|------|-----|
| 1 | Navy đậm | `002060` |
| 2 | Xanh sáng | `0070C0` |
| 3 | Đỏ chính | `953735` |
| 4 | Xanh lá | `598C48` |
| 5 | Vàng hổ phách | `E6AF00` |
| 6 | Cam đất | `C36518` |
| 7 | Nâu vàng | `A99786` |
| 8 | Navy trầm | `002F69` |

### Sequential Palette (NEW — for heat maps, choropleth)

5-step blue ramp from light to dark. Use for ordinal intensity (low → high).

| Step | Hex | Use |
|------|-----|-----|
| 1 (lightest) | `EAF2FA` | Lowest value |
| 2 | `BFD8EC` | Low |
| 3 | `7FB1D9` | Mid |
| 4 | `2E7BBF` | High |
| 5 (darkest) | `002060` | Highest value |

Heat map text on cells: white when step ≥ 3, navy when step ≤ 2.

### Diverging Palette (NEW — for variance, sentiment)

Use when zero is a meaningful midpoint (e.g., budget variance, sentiment).

| Step | Hex | Meaning |
|------|-----|---------|
| -2 | `953735` | Strongly negative |
| -1 | `E5A8A8` | Mildly negative |
| 0 | `F2F2F2` | Neutral |
| +1 | `B8D4B8` | Mildly positive |
| +2 | `2E7D32` | Strongly positive |

### Table Row Colors

| Role | Hex | Usage |
|------|-----|-------|
| Alt row 1 | `F5F5FF` | Light tint |
| Alt row 2 | `FFFFFF` | White |
| Header fill | `002060` | Navy header |
| Highlight row | `FFF7E0` | Emphasized data row |

**CRITICAL NOTE**: Đỏ #C00000 is the PRIMARY emphasis color (110 occurrences in standard deck) — use more frequently than gold/amber.

---

## Typography (VNF Calibri Standard + Consultancy Hierarchy)

All text uses **Calibri** (`typeface="Calibri"`). **NO other fonts allowed.**

### Font Sizes — Full Hierarchy

| Element | Size (pt) | XML sz | Style | Color | Notes |
|---------|-----------|--------|-------|-------|-------|
| Cover title | 48 | `sz="4800"` | Bold | White on Navy | Cover only |
| Cover subtitle | 32 | `sz="3200"` | Bold | White on Navy | Cover only |
| Layer divider | 40 | `sz="4000"` | Bold | White on Navy | Section break |
| **Action Title** *(NEW)* | 24 | `sz="2400"` | Bold | Navy đậm | 1–2 line descriptive headline that states the conclusion |
| **Kicker / Eyebrow** *(NEW)* | 10 | `sz="1000"` | Bold, spc=200 | Đỏ chính / Gray | UPPERCASE, sits above action title |
| Slide title (short form) | 20 | `sz="2000"` | Bold | Navy đậm `002060` | Topic-only titles |
| Sub-header / section | 18 | `sz="1800"` | Bold | Navy | In-content section breaks |
| Card stat (large number) | 32 | `sz="3200"` | Bold | Navy đậm | Hero stat |
| Callout / label | 16 | `sz="1600"` | Bold | Navy | Above stats / cards |
| Body text (main) | 14 | `sz="1400"` | Regular | Body `2C2C2C` | Lead paragraphs |
| Secondary content | 13 | `sz="1300"` | Regular | Body | Default body text |
| **Takeaway / Tagline** *(NEW)* | 13 | `sz="1300"` | Bold | Navy đậm on `D6F1FC` | Zone 4 summary box |
| Notes | 12 | `sz="1200"` | Regular | Body | Annotations |
| Table data | 11 | `sz="1100"` | Regular | Body | Cells |
| Caption | 10 | `sz="1000"` | Italic | Gray | Image captions |
| **Source / Footnote** *(NEW)* | 9 | `sz="900"` | Italic | Gray `888888` | "Source: …" line bottom-left |
| Footer text | 9 | `sz="900"` | Bold | Gray `888888` | Master-managed |

**CRITICAL**: Body text for content slides is **13pt Calibri** (not 14pt).

### The "Action Title" Pattern (NEW — McKinsey/BCG signature)

A consultancy-grade slide leads with a **descriptive headline** that states the conclusion, not the topic. The audience can skim only the action titles and reconstruct the entire argument.

**Bad (topic title)**: "Market Analysis"
**Good (action title)**: "Asia-Pacific demand will outpace global growth by 2.4× through 2030, driven by aquaculture"

**Action title rules**:
- Must be a complete sentence stating a finding, not a topic
- 1–2 lines max (≤ ~140 characters)
- Bold, sentence case (NOT all caps)
- Sits below a small kicker (e.g., "MARKET OUTLOOK · ASIA-PACIFIC")
- Replaces the short-form 20pt title on insight slides

### Font Styling Snippets

**Action title**:
```xml
<a:rPr lang="en-US" sz="2400" b="1">
  <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr>
```

**Kicker (eyebrow)**:
```xml
<a:rPr lang="en-US" sz="1000" b="1" spc="200">
  <a:solidFill><a:srgbClr val="953735"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr>
```

**Takeaway box text**:
```xml
<a:rPr lang="en-US" sz="1300" b="1">
  <a:solidFill><a:srgbClr val="002060"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr>
```

**Source line**:
```xml
<a:rPr lang="en-US" sz="900" i="1">
  <a:solidFill><a:srgbClr val="888888"/></a:solidFill>
  <a:latin typeface="Calibri"/>
</a:rPr>
```

**Bold body / regular body / italic caption** — see existing snippets unchanged.

---

## Glyphs & Symbols (NEW — Consultancy Vocabulary)

### Harvey Balls (graded ratings)

Used in Pattern 14 (Harvey Ball Comparison). Insert as text characters in Calibri.

| Glyph | Char | Meaning | Use |
|-------|------|---------|-----|
| ○ | `&#9675;` | 0 / 5 | None / not present |
| ◔ | `&#9684;` | 1 / 5 | Low / weak |
| ◑ | `&#9681;` | 2.5 / 5 | Medium / partial |
| ◕ | `&#9685;` | 4 / 5 | High / strong |
| ● | `&#9679;` | 5 / 5 | Full / dominant |

Color the glyph with the semantic status color (success / warning / danger) when the rating implies polarity.

### Status Indicators

| Glyph | Meaning | Color |
|-------|---------|-------|
| ▲ | Positive trend / upside | Success `2E7D32` |
| ▼ | Negative trend / downside | Danger `C00000` |
| ◆ | Stable / no change | Neutral `595959` |
| ■ | Filled cell / category marker | Neutral or status |
| ✓ | Yes / present | Success `2E7D32` |
| ✗ | No / absent | Danger `C00000` |
| → | Arrow connector | Navy đậm |

### Numbered Step Badges

For Process Flow (Pattern 4), Pyramid (Pattern 11), and Roadmap (Pattern 17). Use a filled circle with white bold number inside (Calibri 14pt bold).

---

## Standard Slide Structure (VNF 4:3) — Updated 5-Zone Model

```
┌─────────────────────────────────────────────────────────────┐
│ ZONE 1: TITLE / ACTION TITLE                                │
│ y=0 – 3.0 cm · Calibri 24pt bold Navy đậm (action title)   │
│            or 20pt bold Navy đậm (short-form title)        │
│ Master draws the underline beneath. Agent draws nothing.    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ZONE 2: CONTENT                                             │
│ 3.4 – 15.0 cm · body 13pt · 12-column grid                 │
│                                                             │
│ Cards · tables · charts · matrices · at least ONE visual    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ ZONE 3: SOURCE LINE  (optional, required on data slides)   │
│ 15.1 – 15.6 cm · 9pt italic gray                           │
│ "Source: Statista 2025; team analysis"                      │
├─────────────────────────────────────────────────────────────┤
│ ZONE 4: TAGLINE / TAKEAWAY  (Agent MUST create)            │
│ 16.2 – 17.4 cm · Rounded blue box with takeaway sentence   │
├─────────────────────────────────────────────────────────────┤
│ ZONE 5: FOOTER — Managed by slide master (automatic)       │
│ 18.21 – 19.05 cm · LEFT section · CENTER CONFIDENTIAL · # │
│ (master draws its own separator just above the footer text) │
└─────────────────────────────────────────────────────────────┘
```

**Bottom-stack order is fixed**: Content → Source → Tagline → Footer (top to bottom). Source sits **above** the tagline so it never collides with the master's footer-area decorations (which can include a separator at ~17.8cm). Below the tagline, only the master draws — agent never adds horizontal lines.

### Zone Rules

**ZONE 0 — KICKER** (0.4 – 1.1 cm, NEW, optional):
- Use on insight slides (action-title pattern). Skip on layer dividers, cover, ToC, and very dense data slides.
- Format: `LAYER NAME · FIELD TOPIC` or `MARKET · ASIA-PACIFIC`
- 10pt bold Calibri, character spacing 200, Đỏ chính `953735` or Gray `888888`

**ZONE 1 — TITLE** (y=0 – 3.0 cm) — single zone, master draws the underline:
- *Action title mode* (default for insight slides): 24pt bold Navy đậm, **single line preferred (≤80 characters)**. Position: x=230400, y=0, cy=1080000.
- *Short-form mode* (data tables, layer dividers, agendas): 20pt bold Navy đậm, single line topic. Position: x=230400, y=0, cy=720000.
- **Title length rules (v2.2 — strict)**:
  1. Default: keep the action title to **≤80 characters** so it fits on a single 24pt line. The master's underline sits below this and looks correct.
  2. If 80–100 characters: drop the font to **20pt bold** (still single line) instead of letting it wrap.
  3. If >100 characters: rewrite the title shorter. A title that long usually means the author hasn't crystallized the finding.
  4. **NEVER let an action title wrap to 2 lines.** Wrapping crosses the master's underline and produces the visual bug seen in v2.1 generated decks.
- **Agent must NOT draw any horizontal line under the title.** The master draws it. If you draw a second line, you get the double-underline bug. The fix for any title-vs-underline collision is to shorten the title, not to add a manual line.
- **No kicker / eyebrow textbox.** The master's footer already shows the section context (left-aligned section label). Do not add a "LAYER N · TOPIC" textbox at the top of the slide. (Exception: only add a kicker if the user explicitly requests it AND verifies it doesn't conflict with the master.)

**ZONE 2 — CONTENT** (3.4 – 15.0 cm):
- Body text: 13pt Calibri Body `2C2C2C`
- 12-column grid (1.91 cm wide, 0.32 cm gutter)
- MUST include at least ONE visual element
- Content area ends at y=5400000 (15.0cm) to leave room for source line + tagline above the footer.

**ZONE 3 — SOURCE LINE** (15.1 – 15.6 cm) — sits ABOVE the tagline (NEW position v2.2):
- Position: x=230400, y=5436000, cx=6048000, cy=180000.
- 9pt Calibri italic Gray `888888`, left-aligned.
- Required on any slide using third-party data, market sizes, charts, or quotes.
- Format: `Source: <publisher> <year>; <secondary>; team analysis`
- **Why above the tagline?** Most VNF slide masters draw a horizontal separator just above the footer text band (around 17.8cm). A source line below the tagline would cross that separator. Placing the source between content and tagline avoids any collision with master decorations.

**ZONE 4 — TAGLINE / TAKEAWAY** (16.2 – 17.4 cm):
- Position: x=457200, y=5832000, cx=8229600, cy=432000.
- Rounded blue box: `prstGeom prst="roundRect"` with `adj=4500` (matches card corner radius). Background `D6F1FC`, border `0070C0`.
- Text: 13pt bold Calibri Navy đậm. Left-aligned (preferred) or center-aligned.
- Content: the slide's "so what" — the action implication, not just a restatement of the title.
- **Label prefix policy**:
  - *Default*: write the takeaway as a clean sentence with no prefix label.
  - *Optional `→` prefix*: on recommendation slides, for a soft cue.
  - **Do NOT prefix every tagline with "SO WHAT".** That phrase is noise across a 60-slide deck. Reserve "SO WHAT  " for headline action / decision slides only — and even then, sparingly.
- **Tagline is CONTENT — agent must create.**

**ZONE 5 — FOOTER** (18.21 – 19.05 cm):
- Managed by the "Content" layout. LEFT section label · CENTER `CONFIDENTIAL` · RIGHT page number.
- The master also draws a thin horizontal separator just above the footer text. Agent must NOT add anything in the 17.5–18.2cm band — that's reserved for master decorations.
- Agent must NOT manually create footer elements; they come from the master.

### ⚠️ CRITICAL DISTINCTION: Title vs Action Title vs Tagline vs Footer

| Element | Where | What | Who creates |
|---------|-------|------|-------------|
| Short Title | Zone 1 | Topic name (3–5 words), single line | Agent |
| Action Title | Zone 1 | Descriptive sentence stating the conclusion, **single line preferred** | Agent |
| Source line | Zone 3 | "Source: ..." italic gray, above tagline | Agent (when citing data) |
| Tagline / Takeaway | Zone 4 | "So what" / implication for reader, rounded blue box | Agent |
| Footer | Zone 5 | Section · CONFIDENTIAL · page # + master's horizontal separator | Slide master (automatic) |

### ⚠️ CRITICAL: Things the Agent Must NEVER Do

1. **Never draw a manual horizontal line under the title.** The master draws this. Drawing your own creates a double line.
2. **Never add a kicker / eyebrow textbox at the top** (e.g., "LAYER 3 · VALUE CHAIN"). The master footer's section label already conveys this.
3. **Never let an action title wrap to 2 lines** at 24pt. Shorten the title or drop to 20pt single-line.
4. **Never put the source line below the tagline.** The master's footer separator at ~17.8cm collides with anything in the 17.5–18.2cm band. Source goes ABOVE the tagline.
5. **Never add anything between 17.5cm and the bottom of the slide except the tagline (16.2–17.4cm).** That entire bottom band belongs to the master.

---

## Cover Slide Specifications

Use the existing cover from `assets/vnf_slide_template.pptx`. Replace title text only; preserve logos, contact block, and layout. See main 3-step process above.

---

## Slide Number Specifications

Managed by the slide master. Do not add manually. Reference position only:

| Property | Value |
|----------|-------|
| x | 6874941 |
| y | 6516531 |
| Font | Calibri, 9pt |
| Color | Gray `888888` |
| Format | Simple number (e.g., "12"), NOT "Page 12 of 60" |

---

## Quick Reference Card (VNF v2.2)

```
SLIDE: 25.40 × 19.05 cm (4:3 ratio)
FONT: Calibri ONLY

TITLES (single-line ALWAYS — never wrap to 2 lines):
  Cover:        48pt bold white on navy
  Action title: 24pt bold Navy đậm  (≤80 chars; drop to 20pt if 80–100)
  Short title:  20pt bold Navy đậm  (topic, 3–5 words)
  Layer:        40pt bold white on navy
  NO KICKER     (removed in v2.2)

BODY:
  Lead:         14pt regular Body #2C2C2C
  Default:      13pt regular Body
  Notes/Cap:    10–12pt
  Source:       9pt italic Gray #888888  (placed ABOVE the tagline)
  Footer:       9pt bold Gray (auto)

NEVER:
  - Draw a manual horizontal line anywhere on the slide
  - Add a kicker / eyebrow textbox at the top
  - Let titles wrap to 2 lines
  - Place anything in the 17.5–19.05cm band except the tagline (16.2–17.4cm)

COLORS (VNF 15-color brand):
  Navy đậm:     002060  (titles, action titles)
  Đỏ chính:     953735  (PRIMARY emphasis)
  Đỏ critical:  C00000  (warnings)
  Xanh sáng:    0070C0  (data series 1)
  Xanh da trời: D6F1FC  (takeaway boxes)

SEMANTIC STATUS (NEW):
  Success:  dark 2E7D32 / light E8F5E9
  Warning:  dark C97A00 / light FFF4E0
  Danger:   dark C00000 / light FCE4E4
  Info:     dark 0070C0 / light D6F1FC
  Neutral:  dark 595959 / light F2F2F2

CHART CATEGORICAL: 002060 → 0070C0 → 953735 → 598C48 → E6AF00 → C36518 → A99786 → 002F69
HEAT-MAP RAMP:     EAF2FA → BFD8EC → 7FB1D9 → 2E7BBF → 002060
DIVERGING:         953735 ← E5A8A8 ← F2F2F2 → B8D4B8 → 2E7D32

GLYPHS:
  Harvey balls: ○ ◔ ◑ ◕ ●
  Trends: ▲ ◆ ▼      Check/X: ✓ ✗      Arrow: →

LAYOUT (4 zones — kicker removed in v2.2):
  Zone 1 Title         0 – 3.0 cm     (single line, no kicker)
  Zone 2 Content       3.4 – 15.0 cm  (12-col grid, ≥1 visual)
  Zone 3 Source        15.1 – 15.6 cm (optional, ABOVE tagline)
  Zone 4 Takeaway      16.2 – 17.4 cm (rounded blue box)
  Zone 5 Footer        18.21 – 19.05 cm (master, automatic)

  Master decorations sit in 17.5–18.2cm. Agent never draws there.
```

---

## Backwards Compatibility

The 4-zone model from v1 still works. Source line and tagline are **additive** — slides that don't need them keep using the short-title + content + footer structure. Pattern 7 (Layer Divider) and Pattern 8 (Quote Highlight) intentionally skip the source line and tagline.

The v2 kicker / Zone-0 model and the v2.1 manual title underline are **deprecated** — they produced layout regressions. Slides built under v2.0 or v2.1 should be regenerated under v2.2 to match the simplified model.