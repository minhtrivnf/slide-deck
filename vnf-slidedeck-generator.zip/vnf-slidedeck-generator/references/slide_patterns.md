# Slide Layout Patterns (v2 — Consultancy Grade)

This file contains all layout patterns for VNF slide decks. Load this file when choosing how to present slide content.

**v2 changes**: Adds 15 consultancy-grade patterns (10–24) used by BCG / McKinsey / Bain / Roland Berger, including action-title executive summary, Minto pyramid, waterfall, Harvey Balls, BCG-style 2×2, heat map / risk matrix, driver tree, roadmap / Gantt, three-horizon framework, ecosystem map, KPI scorecard, agenda / ToC, and source / methodology slides. Patterns 1–9 from v1 are unchanged.

---

## Pattern Catalog

### Foundational (v1)
| # | Pattern | Best For | Complexity |
|---|---------|----------|------------|
| 1 | Stat Callout (3-col) | Key metrics, findings | Low |
| 2 | Stat Callout (2-col) | Comparisons, contrasts | Low |
| 3 | Data Table | Structured data | Medium |
| 4 | Process Flow | Sequences, timelines | Medium |
| 5 | Icon Grid | Categories, types | Medium |
| 6 | Comparison Matrix (2×2) | SWOT, opportunity/risk | Medium |
| 7 | Layer Divider | Section breaks | Low |
| 8 | Quote Highlight | Key statements | Low |
| 9 | Bar Chart | Comparisons | Medium |

### Consultancy-Grade (v2 — NEW)
| # | Pattern | Best For | Complexity |
|---|---------|----------|------------|
| 10 | Executive Summary (Action Title + 3 Pillars) | Opening / closing slides, single-slide narrative | Medium |
| 11 | Pyramid Principle (Minto) | Argument structure, governing thought | Medium |
| 12 | Waterfall / Bridge Chart | Decomposition of a delta (revenue, cost, headcount) | High |
| 13 | BCG 2×2 Matrix (Axes + Bubbles) | Strategic positioning, portfolio mapping | High |
| 14 | Harvey Ball Comparison | Multi-criteria scoring of options/vendors | Medium |
| 15 | Heat Map / Risk Matrix | Likelihood × impact, geographic intensity | Medium |
| 16 | Driver Tree / Decomposition | Breaking a metric into causal levers | High |
| 17 | Roadmap / Gantt Timeline | Multi-track program plan with phases | High |
| 18 | Maturity Radar (Spider) | Capability assessment, current vs target state | Medium |
| 19 | Three-Horizon Framework | Strategic time-phasing (H1/H2/H3) | Medium |
| 20 | Ecosystem / Stakeholder Map | Central entity + surrounding actors | Medium |
| 21 | KPI Scorecard | Multi-metric status with traffic-light indicators | Medium |
| 22 | Agenda / Table of Contents | Deck-opening navigation slide | Low |
| 23 | Source / Methodology | Data sources, assumptions, scope | Low |
| 24 | Build / Sequential Reveal | 3–5 step framework introduced one element at a time | Medium |

### Pattern Selection Guide

| Content Type | Recommended Pattern |
|--------------|---------------------|
| 3 key metrics | 1 (3-column cards) |
| 2 contrasting findings | 2 (2-column cards) |
| Structured data | 3 (Data table) |
| Process / steps | 4 (Process flow) or 24 (Build) |
| Categories | 5 (Icon grid) |
| SWOT / trade-offs | 6 (Comparison matrix) |
| Section break | 7 (Layer divider) |
| Key quote | 8 (Quote highlight) |
| Simple comparison | 9 (Bar chart) |
| Single-slide narrative / exec summary | **10 (Action title + pillars)** |
| Argument from a single thesis | **11 (Pyramid)** |
| "How did we get from A to B?" | **12 (Waterfall)** |
| Strategic portfolio / positioning | **13 (BCG 2×2)** |
| Vendor / option comparison | **14 (Harvey Balls)** |
| Risk register / geographic intensity | **15 (Heat map)** |
| "Why is X happening?" | **16 (Driver tree)** |
| Multi-quarter implementation plan | **17 (Roadmap)** |
| Capability gap analysis | **18 (Maturity radar)** |
| Long-term strategic plan | **19 (Three horizons)** |
| Stakeholder analysis | **20 (Ecosystem)** |
| Quarterly review / KPI status | **21 (Scorecard)** |
| Deck navigation | **22 (Agenda)** |
| Data caveats / scope | **23 (Source / Method)** |
| Framework reveal | **24 (Build)** |

---

# Patterns 1–9 — Foundational (unchanged from v1)

(For brevity, the v1 specifications for patterns 1–9 remain canonical. They are reproduced inline below.)

## Pattern 1: Stat Callout Cards (3-Column)

Best for: 3 key metrics or findings.

| Column | Card x | Bar x | Text x |
|--------|--------|-------|--------|
| Left | 457200 | 457200 | 660400 |
| Center | 3327400 | 3327400 | 3530600 |
| Right | 6197600 | 6197600 | 6400800 |

Cards: y=1651000, cx=2641600, cy=3429000. Bars: cy=63500. Text: cx=2235200, cy=3048000.

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│▓▓▓▓▓▓▓▓▓▓▓▓▓│  │▓▓▓▓▓▓▓▓▓▓▓▓▓│  │▓▓▓▓▓▓▓▓▓▓▓▓▓│
│ CATEGORY    │  │ CATEGORY    │  │ CATEGORY    │
│    42%      │  │    $2.5B    │  │    2028     │
│ • Point 1   │  │ • Point 1   │  │ • Point 1   │
│ • Point 2   │  │ • Point 2   │  │ • Point 2   │
└─────────────┘  └─────────────┘  └─────────────┘
```

## Pattern 2: Stat Callout Cards (2-Column)

| Column | Card x | Bar x | Text x | Card cx |
|--------|--------|-------|--------|---------|
| Left | 457200 | 457200 | 660400 | 4038600 |
| Right | 4648200 | 4648200 | 4851400 | 4038600 |

Cards: y=1651000, cy=3429000. Text: cx=3632200, cy=3048000.

## Pattern 3: Data Table

| Property | Value |
|----------|-------|
| x | 457200 |
| y | 1651000 |
| cx | 8229600 |
| cy | 4000000 |

Header row 400000, data row 350000. 4-col widths: 2000000 / 2000000 / 2000000 / 2229600.

## Pattern 4: Process Flow / Timeline

| Element | x | cx |
|---------|---|----|
| Step 1 | 457200 | 1800000 |
| Arrow 1 | 2357200 | 400000 |
| Step 2 | 2857200 | 1800000 |
| Arrow 2 | 4757200 | 400000 |
| Step 3 | 5257200 | 1800000 |
| Arrow 3 | 7157200 | 400000 |
| Step 4 | 7657200 | 1800000 |

Steps: y=2000000, cy=2500000.

## Pattern 5: Icon Grid (2×2)

| Position | Circle Center | Label x |
|----------|---------------|---------|
| Top-left | x=1500000, y=2200000 | x=900000 |
| Top-right | x=5500000, y=2200000 | x=4900000 |
| Bottom-left | x=1500000, y=4200000 | x=900000 |
| Bottom-right | x=5500000, y=4200000 | x=4900000 |

Circle diameter 800000 EMU.

## Pattern 6: Comparison Matrix (2×2 SWOT)

| Quadrant | x | y | Fill |
|----------|---|---|------|
| Top-left | 457200 | 1651000 | `E8F5E9` |
| Top-right | 4648200 | 1651000 | `FFF4E0` |
| Bottom-left | 457200 | 3841000 | `FFF4E0` |
| Bottom-right | 4648200 | 3841000 | `E8F5E9` |

Each quadrant cx=4038600, cy=2000000.

## Pattern 7: Layer Divider

| Element | Value |
|---------|-------|
| Background | Full slide, navy `002060` |
| Layer number | 40pt bold white, centered, y=2743200 |
| Layer name | 28pt bold white, centered |

## Pattern 8: Quote Highlight

| Element | Position | Size |
|---------|----------|------|
| Quote mark | x=457200, y=1800000 | 72pt accent |
| Quote text | x=800000, y=2200000, cx=7544000 | 18pt italic navy |
| Attribution | x=800000, y=4000000 | 12pt gray |

## Pattern 9: Bar Chart (Shape-Based, 4 horizontal bars)

| Bar | y | Height | Max Width |
|-----|---|--------|-----------|
| Bar 1 | 1800000 | 600000 | 6000000 |
| Bar 2 | 2600000 | 600000 | 6000000 |
| Bar 3 | 3400000 | 600000 | 6000000 |
| Bar 4 | 4200000 | 600000 | 6000000 |

Bar x=2000000 (after label space). Label x=457200, 11pt navy right-aligned.

---

# Patterns 10–24 — Consultancy Grade (NEW)

---

## Pattern 10: Executive Summary (Action Title + 3 Pillars)

**Best for**: Single-slide-tells-the-story. Opening slides, closing slides, "if-the-CEO-only-reads-one-slide" view.

**Structure**: Kicker on top → bold action title (descriptive sentence) → 3 supporting pillars in a row, each with a heading + 2–3 bullets → "So what" takeaway box at bottom.

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Action Title | 230400 | 0 | 8683200 | 1080000 |
| Pillar 1 | 457200 | 1224000 | 2641600 | 4176000 |
| Pillar 2 | 3327400 | 1224000 | 2641600 | 4176000 |
| Pillar 3 | 6197600 | 1224000 | 2641600 | 4176000 |
| Pillar number badges | (in-pillar) | y=1368000 | 432000 | 432000 |
| Source line (optional) | 230400 | 5436000 | 6048000 | 180000 |
| Takeaway box | 457200 | 5832000 | 8229600 | 432000 |

**v2.2 note**: kicker has been removed. Title sits at y=0. Pillars now start at y=1224000 (3.4cm, below the master's title underline) and end at 5400000 (15.0cm), leaving room for source line + tagline above the master's footer band.

Each pillar contains:
- Numbered badge circle (Calibri 14pt bold white, navy fill, ø=432000)
- Pillar heading (16pt bold Navy đậm)
- 2–3 bullets (13pt body)

### When to Use

- Day-1 framing slide
- Closing recommendation slide
- "Storyline summary" required by exec audience
- Whenever the deck has only 5 minutes of airtime

### Visual Example

```
KICKER · CATEGORY                                        (10pt red bold)
Three structural shifts will reshape the category by 2028
                                                         (24pt action title)
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ ① REGULATION │  │ ② TECHNOLOGY │  │ ③ DEMAND     │
│              │  │              │  │              │
│ Heading line │  │ Heading line │  │ Heading line │
│              │  │              │  │              │
│ • Bullet 1   │  │ • Bullet 1   │  │ • Bullet 1   │
│ • Bullet 2   │  │ • Bullet 2   │  │ • Bullet 2   │
│ • Bullet 3   │  │ • Bullet 3   │  │ • Bullet 3   │
└──────────────┘  └──────────────┘  └──────────────┘
[Takeaway: "So what" — single sentence implication for the reader]
```

---

## Pattern 11: Pyramid Principle (Minto)

**Best for**: Argument structure, governing-thought communication, a slide that mirrors the entire deck's logic.

**Structure**: Top tier (governing thought) → middle tier (3 supporting arguments) → bottom tier (3 evidence points per argument). Reads top-down.

### Layout Coordinates (v2.2 — top tier widened, connector geometry explicit)

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Top tier (1 box, **widened for governing-thought sentence**) | 1828800 | 1224000 | 5486400 | 1080000 |
| Middle tier (3 boxes) | 457200 / 3327400 / 6197600 | 2592000 | 2641600 | 720000 |
| Bottom tier (3-col stack) | 457200 / 3327400 / 6197600 | 3456000 | 2641600 | 1944000 |
| Connector lines | see explicit geometry below | — | — | — |

Top fill: Navy đậm `002060`, white text. Middle: Xanh sáng `0070C0`, white text. Bottom: white fill, navy border, body text.

**v2.2 sizing fix**: top tier widened to cx=5486400 (15.2cm) and cy=1080000 (3.0cm) so a 1–2 sentence governing thought ("Vietnam's <40% survival rate is the single most binding economic constraint…") fits comfortably. Old cx=2641600 caused text overflow.

### Connector Geometry (CRITICAL — fixes wrong-direction bug)

The 3 connectors must go from the **bottom-center of the TOP tier box** to the **top-center of EACH middle-tier box** (one connector per lower box, fanning down-left / straight-down / down-right). The agent must NOT connect lower boxes to each other or anchor connectors to the wrong box.

**Anchor points (computed once)**:

| Point | x | y | Note |
|-------|---|---|------|
| Top box bottom-center (start for all 3 connectors) | 4572000 | 2304000 | (top_x + top_cx/2, top_y + top_cy) |
| Lower box 1 top-center (left) | 1778000 | 2592000 | (457200 + 2641600/2, middle_y) |
| Lower box 2 top-center (middle) | 4648200 | 2592000 | (3327400 + 2641600/2, middle_y) |
| Lower box 3 top-center (right) | 7518400 | 2592000 | (6197600 + 2641600/2, middle_y) |

**The 3 connector cxnSp specs**:

```xml
<!-- Connector 1: top → lower-left, diagonal down-left -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="601" name="PyramidConn1"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>   <!-- bottom of top box -->
      <a:endCxn id="[LOWER_1_ID]" idx="0"/>  <!-- top of lower box 1 -->
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm flipH="1">
      <a:off x="1778000" y="2304000"/>
      <a:ext cx="2794000" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Connector 2: top → lower-middle, near-vertical -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="602" name="PyramidConn2"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>
      <a:endCxn id="[LOWER_2_ID]" idx="0"/>
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="4572000" y="2304000"/>
      <a:ext cx="76200" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>

<!-- Connector 3: top → lower-right, diagonal down-right -->
<p:cxnSp>
  <p:nvCxnSpPr>
    <p:cNvPr id="603" name="PyramidConn3"/>
    <p:cNvCxnSpPr>
      <a:stCxn id="[TOP_BOX_ID]" idx="2"/>
      <a:endCxn id="[LOWER_3_ID]" idx="0"/>
    </p:cNvCxnSpPr>
    <p:nvPr/>
  </p:nvCxnSpPr>
  <p:spPr>
    <a:xfrm>
      <a:off x="4572000" y="2304000"/>
      <a:ext cx="2946400" cy="288000"/>
    </a:xfrm>
    <a:prstGeom prst="line"><a:avLst/></a:prstGeom>
    <a:ln w="9525"><a:solidFill><a:srgbClr val="888888"/></a:solidFill></a:ln>
  </p:spPr>
</p:cxnSp>
```

**Anchor IDs**: Replace `[TOP_BOX_ID]`, `[LOWER_1_ID]`, `[LOWER_2_ID]`, `[LOWER_3_ID]` with the actual `id` attributes of the corresponding `p:sp` shapes you created. The `idx` values: `0` = top edge, `1` = right edge, `2` = bottom edge, `3` = left edge of a rectangle.

**Connector geometry rule (general)**: for any connector from point A to point B,
- `<a:off x>` = `min(A.x, B.x)`
- `<a:off y>` = `min(A.y, B.y)`
- `<a:ext cx>` = `abs(B.x - A.x)`
- `<a:ext cy>` = `abs(B.y - A.y)`
- `flipH="1"` if going right-to-left (B.x < A.x)
- `flipV="1"` if going bottom-to-top (B.y < A.y)

Without correct flip flags, the line will visually go from the wrong corner of the bounding box, producing the "wrong-direction" bug. **Always set `flipH="1"` for diagonals going down-left from a centered top box** (this is the most common mistake).

### When to Use

- "Why should we believe this?" slides
- Strategy recommendations
- Investment thesis communication

### Visual Example

```
               ┌─────────────────────────┐
               │ GOVERNING THOUGHT       │
               │ Bold, single sentence   │
               └────────┬────────────────┘
        ┌──────────────┬┴┬──────────────┐
   ┌────┴────┐    ┌────┴────┐    ┌────┴────┐
   │ ARG 1   │    │ ARG 2   │    │ ARG 3   │
   └────┬────┘    └────┬────┘    └────┬────┘
   ┌────┴────┐    ┌────┴────┐    ┌────┴────┐
   │ • Ev 1  │    │ • Ev 1  │    │ • Ev 1  │
   │ • Ev 2  │    │ • Ev 2  │    │ • Ev 2  │
   │ • Ev 3  │    │ • Ev 3  │    │ • Ev 3  │
   └─────────┘    └─────────┘    └─────────┘
```

---

## Pattern 12: Waterfall / Bridge Chart

**Best for**: Showing how a starting value becomes an ending value through additive and subtractive drivers (revenue bridge, cost decomposition, headcount evolution, EBITDA walk).

**Structure**: Anchor bar (start) → series of step bars (positive = green, negative = red) → anchor bar (end). Connector dashed lines between bar tops.

### Layout Coordinates (6-step bridge)

| Element | x | cx | Notes |
|---------|---|----|----|
| Start anchor | 457200 | 1100000 | Navy fill, full height bar |
| Driver 1 (+) | 1700000 | 1100000 | Green fill, floats from prev top |
| Driver 2 (–) | 2900000 | 1100000 | Red fill, floats down |
| Driver 3 (+) | 4100000 | 1100000 | Green |
| Driver 4 (–) | 5300000 | 1100000 | Red |
| End anchor | 6500000 | 1100000 | Navy, full height |
| Plot area | y=1800000 | cy=3600000 | Y-axis baseline at y=5400000 |
| Connector lines | between bar tops | dashed `D9D9D9` | — |

Above each bar: value label (12pt bold). Below each bar: driver name (10pt). Use `+` and `–` prefixes on delta values.

### When to Use

- Variance walk (Q3 vs Q2)
- Margin bridge
- Capacity / headcount build-up
- Funnel-style conversion explanation

### Visual Example

```
       ┌──┐
       │+5│             ┌──┐
 ┌──┐  │  │  ┌──┐  ┌──┐ │+3│
 │  │  │  │  │  │  │+2│ │  │  ┌──┐
 │40│  │  │  │-3│  │  │ │  │  │47│
 │  │  │  │  │  │  │  │ │  │  │  │
 └──┘  └──┘  └──┘  └──┘ └──┘  └──┘
 START   A     B     C    D    END
       (+5) (-3)  (+2) (+3)
```

---

## Pattern 13: BCG 2×2 Matrix (Axes + Bubbles)

**Best for**: Strategic positioning, portfolio analysis, market vs capability assessment. Different from Pattern 6 (SWOT) — Pattern 13 has **labeled axes** and **plotted points/bubbles**, not pre-defined quadrant labels.

**Structure**: X and Y axes with low/high labels → 4 quadrants (light tint or white) → quadrant labels (top-left of each quadrant) → 5–8 plotted bubbles representing options, with size = third variable.

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Plot area | 1300000 | 1620000 | 6800000 | 4200000 |
| Y-axis label (vertical) | 230400 | 3060000 | 800000 | 1320000 |
| X-axis label (horizontal) | 1300000 | 5940000 | 6800000 | 252000 |
| Quadrant TL label | 1400000 | 1700000 | 3200000 | 252000 |
| Quadrant TR label | 4900000 | 1700000 | 3200000 | 252000 |
| Quadrant BL label | 1400000 | 3700000 | 3200000 | 252000 |
| Quadrant BR label | 4900000 | 3700000 | 3200000 | 252000 |
| Bubbles | within plot | — | ø 360000–720000 | data-driven |

Quadrant fills: TL `F2F2F2` (neutral), TR `E8F5E9` (success/star), BL `FCE4E4` (danger/dog), BR `FFF4E0` (warning/question mark). Adjust labels to fit your axes.

### When to Use

- Market attractiveness × competitive position
- Effort × impact prioritization
- Risk × opportunity portfolio mapping
- Initiative scoring

### Visual Example

```
HIGH │  ┌────────────────┬────────────────┐
     │  │ QUESTION MARKS │ STARS          │
     │  │   ●            │     ●  ●       │
     │  │     ●          │       ●        │
Y    │  ├────────────────┼────────────────┤
     │  │ DOGS           │ CASH COWS      │
     │  │   ●            │       ●        │
LOW  │  │                │     ●          │
     │  └────────────────┴────────────────┘
     └─────────────────────────────────────
        LOW          X-AXIS           HIGH
```

---

## Pattern 14: Harvey Ball Comparison

**Best for**: Multi-criteria scoring of 3–6 options (vendor selection, technology comparison, market screening, framework comparison).

**Structure**: Table with options as columns and criteria as rows. Cells contain Harvey Ball glyphs (○ ◔ ◑ ◕ ●) colored by status. Header row + criteria rows. Optional "weighted score" final row.

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Table | 457200 | 1620000 | 8229600 | 3960000 |
| Criteria column | 457200 | — | 2700000 | — |
| Option columns (4) | — | — | 1382400 each | — |
| Header row | — | 1620000 | — | 360000 |
| Criteria rows | — | — | — | 432000 each |
| Footer score row | — | bottom | — | 504000 |

### Glyph Reference

| Glyph | Meaning |
|-------|---------|
| ○ | Does not meet |
| ◔ | Partially meets |
| ◑ | Meets baseline |
| ◕ | Meets well |
| ● | Best in class |

Glyph color: pair with semantic status (`2E7D32` for ●/◕, `C97A00` for ◑/◔, `C00000` for ○ when polarity matters; otherwise navy).

### When to Use

- Vendor / RFP scoring
- Technology evaluation
- Build/buy/partner decision
- Strategic option comparison

### Visual Example

```
┌──────────────────┬────────┬────────┬────────┬────────┐
│ CRITERIA         │ OPT A  │ OPT B  │ OPT C  │ OPT D  │
├──────────────────┼────────┼────────┼────────┼────────┤
│ Cost             │   ●    │   ◕    │   ◑    │   ◔    │
│ Time-to-market   │   ◑    │   ●    │   ◕    │   ◔    │
│ Risk             │   ◕    │   ◕    │   ◑    │   ●    │
│ Strategic fit    │   ●    │   ◕    │   ◕    │   ◑    │
│ Capability needs │   ◔    │   ◑    │   ●    │   ◕    │
├──────────────────┼────────┼────────┼────────┼────────┤
│ WEIGHTED SCORE   │ 4.2/5  │ 3.8/5  │ 3.4/5  │ 3.2/5  │
└──────────────────┴────────┴────────┴────────┴────────┘
```

---

## Pattern 15: Heat Map / Risk Matrix

**Best for**: Likelihood × impact risk register, geographic intensity, priority × effort matrix, capability scoring across regions/products.

**Structure**: Grid of cells (typically 5×5 or 4×4) colored along the sequential or diverging palette. Optional point labels inside cells (risks, items). Axis labels on X and Y.

### Layout Coordinates (5×5 grid)

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Grid plot | 1500000 | 1620000 | 6500000 | 4200000 |
| Cell width | — | — | 1300000 | — |
| Cell height | — | — | 840000 | — |
| Y-axis label | 230400 | 3060000 | 1100000 | 1320000 |
| X-axis label | 1500000 | 5940000 | 6500000 | 252000 |
| Y tick labels | 1100000 | per row | 360000 | 840000 |
| X tick labels | per col | 5760000 | 1300000 | 180000 |

Cell fills: use sequential palette (`EAF2FA → BFD8EC → 7FB1D9 → 2E7BBF → 002060`) for monotonic intensity, OR diverging palette for risk (low-likelihood-low-impact = green, high-likelihood-high-impact = red).

Inside-cell labels: white when cell is dark (top-right of risk matrix), navy when cell is light. Text 11pt bold, optionally a circle badge with risk number.

### When to Use

- Risk matrix (likelihood × impact)
- Country attractiveness vs feasibility
- Customer segment heat map
- Capability gap by function × geography

### Visual Example

```
      │ LOW          MEDIUM         HIGH        VERY HIGH
HIGH  │ ░░  ▓▓  ▓▓  ▓▓  ██   (R3)
      │
MED   │ ░░  ▓▓  ▓▓  ██  ██
      │              (R1)
LOW   │ ░░  ░░  ▓▓  ▓▓  ██
      │ (R2)
─────────────────────────────────────
LIKELIHOOD →
```

---

## Pattern 16: Driver Tree / Decomposition

**Best for**: Decomposing a top-level metric into causal drivers ("Why is revenue down? → price × volume → mix vs spot → segment A/B/C").

**Structure**: Left-anchored root node → branching to second-level children (typically 2–4) → optional third level. Each node has a metric name + value + delta vs baseline. Branch lines connect nodes.

### Layout Coordinates (3-level tree)

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Root node | 457200 | 3060000 | 1900000 | 720000 |
| L2 nodes (3) | 2900000 | 1620000 / 3060000 / 4500000 | 1900000 | 720000 |
| L3 nodes (up to 6) | 5300000 | 1080000 / 2160000 / 3240000 / 4320000 / 5400000 / 6480000 | 1900000 | 540000 |
| Branch lines | between levels | — | — | — |

Root fill: Navy đậm. L2: Xanh sáng. L3: white with navy border. Show metric value in 14pt bold, name in 10pt regular, delta arrow ▲▼ with status color.

### When to Use

- Margin / cost decomposition
- "Why are we missing target?"
- Customer LTV breakdown
- Capacity constraint diagnosis

### Visual Example

```
┌──────────┐                 ┌──────────┐
│ TOTAL    ├──┬──────────────┤ Driver A │──┬─[ Sub A1 ]
│ Revenue  │  │              │ ▼ -8%    │  └─[ Sub A2 ]
│ $4.2M    │  │              └──────────┘
│ ▼ -12%   │  │              ┌──────────┐
└──────────┘  ├──────────────┤ Driver B │──┬─[ Sub B1 ]
              │              │ ▼ -3%    │  └─[ Sub B2 ]
              │              └──────────┘
              │              ┌──────────┐
              └──────────────┤ Driver C │──┬─[ Sub C1 ]
                             │ ▲ +2%    │  └─[ Sub C2 ]
                             └──────────┘
```

---

## Pattern 17: Roadmap / Gantt Timeline

**Best for**: Multi-track program plans, quarterly initiatives, implementation timelines.

**Structure**: Horizontal time axis (quarters or months) at top → workstream rows on the left → bars spanning months/quarters within each row → milestone diamonds for key dates.

### Layout Coordinates (4 workstreams × 8 quarters)

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Time header | 2200000 | 1620000 | 6500000 | 360000 |
| Workstream label col | 230400 | — | 1900000 | — |
| Plot area | 2200000 | 2160000 | 6500000 | 3600000 |
| Each workstream row | — | — | — | 800000 |
| Bar height | — | — | — | 432000 |
| Quarter column width | — | — | 812500 | — |
| Milestone diamond | — | — | ø 252000 | 252000 |

Bar colors: use categorical palette indexed by workstream. Phase 1 = Navy đậm, Phase 2 = Xanh sáng, Phase 3 = Xanh lá, Phase 4 = Đỏ chính. Milestone diamonds: Vàng hổ phách `E6AF00`.

Optional: vertical "TODAY" line at the current quarter (dashed Đỏ critical).

### When to Use

- Strategy execution roadmap
- Product launch plan
- Transformation program
- M&A integration timeline

### Visual Example

```
              Q1'26  Q2'26  Q3'26  Q4'26  Q1'27  Q2'27  Q3'27  Q4'27
Workstream A  ████████████◆           ████████◆
Workstream B         ████████████████████
Workstream C  ◆████          ████████████◆          ████████
Workstream D                        ████████████████████████████
                            │TODAY│
```

---

## Pattern 18: Maturity Radar (Spider Chart)

**Best for**: Capability assessment current vs target state, multi-dimensional readiness scoring.

**Structure**: Radial polygon with 5–8 axes. Two overlapping shapes: "current state" (lighter fill, lower values) and "target state" (darker outline, higher values).

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Radar plot | 1500000 | 1620000 | 4200000 | 4200000 |
| Legend | 6000000 | 2160000 | 2400000 | 1800000 |
| Axis labels | around radar | — | per label | — |
| Capability bullet list | 6000000 | 4200000 | 2400000 | 1620000 |

Render the radar via stacked rotated rectangles or, ideally, an embedded chart object. Polygon fills: current state = `D6F1FC` 40% opacity with `0070C0` outline, target state = `953735` outline (no fill) or 20% opacity fill.

Scale: 0–5 with concentric pentagonal grid lines (light gray `D9D9D9`).

### When to Use

- Digital maturity assessment
- Capability current vs target
- Vendor capability fit
- Function-level readiness

### Visual Example

```
            Strategy
              5
           4 / \
          3 / | \  Tech
  People   /  |  \
   ┌───  2 ───┼───  ─┐
          \  |  /
           3\|/
            4
          Process
       (current = inner shape, target = outer shape)
```

---

## Pattern 19: Three-Horizon Framework (McKinsey)

**Best for**: Long-term strategic planning across short / medium / long-term horizons.

**Structure**: 3 ascending S-curves on a time × value plot. H1 (today, defend & extend), H2 (build emerging businesses), H3 (create options). Each horizon labeled with timeframe, theme, and 2–3 initiative bullets.

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Plot area | 230400 | 1620000 | 5500000 | 3960000 |
| H1 curve | within plot | y-band 4400000 | rises Y1–Y2 | — |
| H2 curve | within plot | y-band 3200000 | rises Y2–Y4 | — |
| H3 curve | within plot | y-band 2000000 | rises Y4–Y6 | — |
| H1 panel (right) | 6000000 | 1620000 | 2700000 | 1300000 |
| H2 panel (right) | 6000000 | 3060000 | 2700000 | 1300000 |
| H3 panel (right) | 6000000 | 4500000 | 2700000 | 1300000 |
| Y-axis label | 0 | 3060000 (rotated) | 230400 | 1320000 |
| X-axis label | 230400 | 5940000 | 5500000 | 252000 |

Curve colors: H1 = Navy đậm, H2 = Xanh sáng, H3 = Đỏ chính. Right panels: thin border in matching color.

### When to Use

- Long-range strategic plan
- Innovation portfolio
- Growth platform sequencing

### Visual Example

```
VALUE  │                                ___H3___
       │                          __H2_/
       │                    __H2_/
       │            _H1____/                       │ HORIZON 1: 0–18mo
       │      _H1__/                               │  Defend core
       │_H1__/                                     │
       └────────────────────────────────── TIME    │ HORIZON 2: 18–36mo
        Year 1   Year 2   Year 3   Year 4          │  Build adjacent
                                                   │
                                                   │ HORIZON 3: 36mo+
                                                   │  Create options
```

---

## Pattern 20: Ecosystem / Stakeholder Map

**Best for**: Stakeholder analysis, ecosystem mapping, partner landscape, customer-centric value flow.

**Structure**: Central entity (organization, customer, product) → orbital rings of stakeholders → connection lines indicating relationships. Optional grouping into quadrants (suppliers, partners, regulators, customers).

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Center node | 3850000 | 2700000 | 1450000 | 1450000 |
| Inner-ring nodes (4) | (placed at NW/NE/SW/SE around center) | — | 1300000 | 720000 |
| Outer-ring nodes (8) | (placed at 8 cardinal points further out) | — | 1100000 | 540000 |
| Quadrant labels | corners | — | 1900000 | 252000 |
| Connector lines | center → each node | dashed `888888` | — | — |

Center fill: Navy đậm with white text. Inner ring: Xanh sáng. Outer ring: white with navy border.

Inner-ring suggested coordinates around center (3850000, 2700000):
- NW: x=1700000, y=1700000
- NE: x=5800000, y=1700000
- SW: x=1700000, y=4200000
- SE: x=5800000, y=4200000

### When to Use

- Stakeholder map for change program
- Ecosystem landscape
- Partner / channel architecture
- Customer-360 view

### Visual Example

```
            [Regulator]      [Investor]
                  \              /
       [Supplier]──┐  ┌─────┐  ┌──[Channel]
                    \│ CORE │/
                     │ ORG  │
                    /│      │\
       [Partner]──┘  └─────┘  └──[Customer]
                  /              \
             [Media]         [Community]
```

---

## Pattern 21: KPI Scorecard

**Best for**: Quarterly business review, monthly metrics, OKR status, leadership dashboard.

**Structure**: Grid of 4–8 KPI tiles, each containing: KPI name, current value (large), target, variance, status indicator (▲ ▼ ◆ traffic light), and optional sparkline.

### Layout Coordinates (2×4 grid, 8 tiles)

| Tile | x | y |
|------|---|---|
| 1 | 457200 | 1620000 |
| 2 | 2607400 | 1620000 |
| 3 | 4757600 | 1620000 |
| 4 | 6907800 | 1620000 |
| 5 | 457200 | 3420000 |
| 6 | 2607400 | 3420000 |
| 7 | 4757600 | 3420000 |
| 8 | 6907800 | 3420000 |

Each tile: cx=2030200, cy=1640000.

Inside each tile (top-to-bottom):
- Status bar (top, 36000 EMU thin): semantic color (success/warning/danger)
- KPI name (12pt bold Navy, top-left)
- Status glyph (▲ ▼ ◆, top-right, semantic color)
- Current value (28pt bold Navy đậm, centered)
- Target / vs prior (10pt gray, centered below value)
- Optional sparkline (bottom strip, 360000 EMU)

### When to Use

- QBR / MBR opening slide
- Executive dashboard
- OKR status review
- Health-of-business monitoring

### Visual Example

```
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ ▓ REVENUE  ▲ │ │ ▓ MARGIN   ▲ │ │ ▓ NPS      ◆ │ │ ▓ CHURN    ▼ │
│              │ │              │ │              │ │              │
│   $4.2M      │ │    24.8%     │ │     62       │ │    4.1%      │
│              │ │              │ │              │ │              │
│ Target $4.0M │ │ Target 23%   │ │ Target 60    │ │ Target 3.5%  │
└──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ ▓ NEW LOGOS  │ │ ▓ ARR        │ │ ▓ CAC PAY    │ │ ▓ ENGAGEMENT │
│   ...        │ │   ...        │ │   ...        │ │   ...        │
└──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘
```

Top status bar color: green/amber/red depending on KPI vs target.

---

## Pattern 22: Agenda / Table of Contents

**Best for**: Slide 2 of every consultancy deck. Sets reader expectations.

**Structure**: Numbered list of sections (one per layer or chapter) with optional brief description. Current section can be highlighted (used as a section divider variant).

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Title "AGENDA" | 230400 | 0 | 8683200 | 720000 |
| Item rows (5–8) | 1000000 | 1620000 + N × 720000 | 7400000 | 600000 |
| Number badge | 1000000 | per row | 432000 | 432000 |
| Item title | 1600000 | per row | 4200000 | 432000 |
| Page indicator | 7400000 | per row | 1000000 | 432000 |

Row fill: alternating white / `F5F5FF`. Number badge: navy circle + white bold number 14pt. Item title: 16pt bold navy. Page indicator: 11pt gray italic, right-aligned ("p. 12").

For the **section divider variant**, highlight the current item's row in `D6F1FC` and bold the title.

### When to Use

- Slide 2 of any deck > 15 slides
- Section-divider replacement for Pattern 7 when you want list context

### Visual Example

```
AGENDA
─────────────────────────────────────────────────────
 ①  Context & framing                          p.  3
 ②  Market dynamics                            p.  8
 ③  Strategic options                          p. 18
 ④  Recommended path forward                   p. 32
 ⑤  Implementation roadmap                     p. 41
 ⑥  Risks & mitigations                        p. 52
 ⑦  Appendix                                   p. 58
```

---

## Pattern 23: Source / Methodology

**Best for**: End-of-deck slide listing data sources, assumptions, scope, and exclusions. Required for any deck cited externally.

**Structure**: Title "SOURCES & METHODOLOGY" → 3 columns: Sources (with citation), Methodology / Approach (bullet list), Assumptions & Caveats (bullet list).

### Layout Coordinates

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Sources column | 457200 | 1620000 | 2641600 | 4320000 |
| Methodology column | 3327400 | 1620000 | 2641600 | 4320000 |
| Assumptions column | 6197600 | 1620000 | 2641600 | 4320000 |
| Column headers | per col | y=1620000 | — | 360000 |

Column headers: 13pt bold Navy đậm with bottom border (1pt navy). Body text: 11pt regular body, bullet list with hyphen markers (use `–` not `•` for sources).

### When to Use

- Final slide of any cited deck
- Required by enterprise audit
- Whenever data is borrowed from external sources

---

## Pattern 24: Build / Sequential Reveal Framework

**Best for**: Introducing a 3–5 step framework one element at a time across sequential slides (build slides), all anchored to the same structural diagram.

**Structure**: Same diagram on each slide of the build, with one new element highlighted (full color) and previously revealed elements dimmed (gray). Used for storytelling — present builds the audience's understanding step by step.

### Layout Coordinates (5 elements arranged horizontally)

| Element | x | y | cx | cy |
|---------|---|---|----|----|
| Stage 1 | 457200 | 2160000 | 1630000 | 1800000 |
| Stage 2 | 2200000 | 2160000 | 1630000 | 1800000 |
| Stage 3 | 3942800 | 2160000 | 1630000 | 1800000 |
| Stage 4 | 5685600 | 2160000 | 1630000 | 1800000 |
| Stage 5 | 7428400 | 2160000 | 1715000 | 1800000 |
| Detail panel below | 457200 | 4140000 | 8229600 | 1800000 |

On build slide N: stage N gets full Navy đậm fill + white text. Stages 1..N-1 get `F2F2F2` fill + Gray text. Stages N+1..5 get white fill + Light gray border.

Below the row, an expanded detail panel describes only the focused stage.

### When to Use

- Introducing a methodology over 5 slides
- Storyline builds in keynote-style decks
- Training / onboarding decks

### Visual Example (Slide 3 of 5 in the build)

```
[Step 1] [Step 2] [STEP 3] [Step 4] [Step 5]
 ░░░     ░░░     ███████   ⬚⬚⬚      ⬚⬚⬚
                ┌─────────────────────────┐
                │ STEP 3 — ANALYZE         │
                │ • Drill into root cause   │
                │ • Quantify each driver    │
                │ • Validate with finance   │
                └─────────────────────────┘
```

(`░░░` = dimmed/already shown, `███` = current focus, `⬚⬚⬚` = upcoming/outlined)

---

## Tagline Integration (Reference — unchanged from v1)

Taglines are blue boxes at the bottom of the content area (Zone 4 in v2 spec) containing summary/conclusion text. They are NOT the footer (Zone 5). Add taglines whenever the outline specifies a "Field Tagline" or the slide is the final in a field.

| Property | Value |
|----------|-------|
| Zone | Zone 4 (sits ABOVE Zone 3 source line, well above footer) |
| y position | 5832000 EMU (16.2 cm) — fixed in v2.1 |
| Height | 432000 EMU (1.2 cm) |
| Width | 8229600 EMU (full content width less margins) |
| Shape | `roundRect` with `adj=4500` (rounded corners — matches card style) |
| Background | `D6F1FC` |
| Border | `0070C0` (1pt) |
| Text | 13pt Calibri bold, Navy đậm `002060` |
| Prefix label | None by default. Use `→` arrow on recommendation slides; reserve "SO WHAT" for headline action slides only — see `slide_templates.md` "Prefix Policy". |

---

## Avoiding Repetition

**Rule**: No two consecutive slides should use the same pattern.

**Consultancy storyline rule (NEW)**: Each layer should ideally include at least one of the structural patterns (10, 11, 12, 13, 16, 17, 19) to give the layer a backbone, then 2–4 of the supporting patterns (1–9, 14, 15, 18, 20, 21, 24) as evidence. End each layer with a Pattern 10 or Pattern 21 closing.

**Rotation example for a 12-slide layer**:
```
1. Pattern 22 (Agenda highlight)         ← layer opener
2. Pattern 10 (Action title + 3 pillars) ← thesis
3. Pattern 12 (Waterfall)                ← evidence
4. Pattern 14 (Harvey Balls)             ← evidence
5. Pattern 1  (Stat callout)             ← evidence
6. Pattern 16 (Driver tree)              ← causal logic
7. Pattern 13 (BCG 2×2)                  ← positioning
8. Pattern 6  (SWOT 2×2)                 ← internal/external
9. Pattern 17 (Roadmap)                  ← what we'll do
10. Pattern 21 (KPI scorecard)           ← how we measure
11. Pattern 11 (Pyramid)                 ← argument summary
12. Pattern 7  (Layer divider)           ← transition
```