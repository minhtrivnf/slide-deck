#!/usr/bin/env python3
"""
Pre-pack PPTX validator (VNF v2.2 file-integrity gate A).

Validates an unpacked PPTX directory before repacking, catching the most
common causes of "PowerPoint won't open the file" errors:

  - Duplicate <p:cNvPr id="N"> shape IDs within any single slide
  - Duplicate <Relationship Id="rIdN"> in any *.rels file
  - Duplicate <p:sldId id="N"> in presentation.xml (and sldId < 256)
  - Relationship targets that don't exist on disk
  - Slides missing their _rels file
  - Content types missing for declared parts

Usage:
    python validate_pptx_unpacked.py /path/to/unpacked/

Exits 0 on success, 1 on any validation failure.
"""

import os
import sys
from collections import Counter
from xml.etree import ElementTree as ET

NS = {
    'p':   'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r':   'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'rel': 'http://schemas.openxmlformats.org/package/2006/relationships',
    'ct':  'http://schemas.openxmlformats.org/package/2006/content-types',
}


def find_duplicates(items):
    """Return list of items appearing more than once."""
    return [k for k, v in Counter(items).items() if v > 1]


def validate_unpacked(unpacked_dir):
    errors = []

    # ---- 1. Per-slide shape ID uniqueness ----
    slides_dir = os.path.join(unpacked_dir, 'ppt', 'slides')
    slide_files = []
    if os.path.isdir(slides_dir):
        slide_files = sorted([f for f in os.listdir(slides_dir) if f.endswith('.xml')])
        for fn in slide_files:
            path = os.path.join(slides_dir, fn)
            try:
                tree = ET.parse(path)
            except ET.ParseError as e:
                errors.append(f"{fn}: malformed XML — {e}")
                continue
            # cNvPr appears in both p: (slide-level shapes) and a: (drawingml deep elements)
            # namespaces. Match both via local-name to be safe.
            ids = [el.get('id')
                   for el in tree.iter()
                   if el.tag.rpartition('}')[2] == 'cNvPr' and el.get('id') is not None]
            dups = find_duplicates(ids)
            if dups:
                errors.append(f"{fn}: duplicate cNvPr ids {dups}")

    # ---- 2. Every slideN.xml has a matching _rels/slideN.xml.rels ----
    slide_rels_dir = os.path.join(slides_dir, '_rels')
    if slide_files:
        if not os.path.isdir(slide_rels_dir):
            errors.append("missing directory: ppt/slides/_rels (slides have no relationship files)")
        else:
            for fn in slide_files:
                rels_fn = fn + '.rels'
                if not os.path.exists(os.path.join(slide_rels_dir, rels_fn)):
                    errors.append(f"missing rels file: ppt/slides/_rels/{rels_fn}")

    # ---- 3. presentation.xml.rels — duplicate rIds + targets exist ----
    pres_rels_path = os.path.join(unpacked_dir, 'ppt', '_rels', 'presentation.xml.rels')
    if os.path.exists(pres_rels_path):
        try:
            tree = ET.parse(pres_rels_path).getroot()
            rids = [r.get('Id') for r in tree if r.get('Id')]
            dups = find_duplicates(rids)
            if dups:
                errors.append(f"presentation.xml.rels: duplicate rIds {dups}")
        except ET.ParseError as e:
            errors.append(f"presentation.xml.rels: malformed XML — {e}")

    # ---- 4. presentation.xml — duplicate sldIds + sldId >= 256 ----
    pres_path = os.path.join(unpacked_dir, 'ppt', 'presentation.xml')
    if os.path.exists(pres_path):
        try:
            pres = ET.parse(pres_path).getroot()
            sld_ids = [s.get('id') for s in pres.iter('{%s}sldId' % NS['p'])]
            dups = find_duplicates(sld_ids)
            if dups:
                errors.append(f"presentation.xml: duplicate sldId {dups}")
            for sid in sld_ids:
                try:
                    if int(sid) < 256:
                        errors.append(
                            f"presentation.xml: sldId={sid} is < 256 (PowerPoint reserves IDs below 256)"
                        )
                except (TypeError, ValueError):
                    errors.append(f"presentation.xml: non-integer sldId={sid!r}")
            # Also check that every sldId references an rId that exists
            sld_rids = [s.get('{%s}id' % NS['r']) for s in pres.iter('{%s}sldId' % NS['p'])]
            if os.path.exists(pres_rels_path):
                rels = ET.parse(pres_rels_path).getroot()
                known_rids = {r.get('Id') for r in rels}
                for rid in sld_rids:
                    if rid and rid not in known_rids:
                        errors.append(
                            f"presentation.xml: sldId references rId={rid} but it's not in presentation.xml.rels"
                        )
        except ET.ParseError as e:
            errors.append(f"presentation.xml: malformed XML — {e}")

    # ---- 5. All relationship targets exist on disk ----
    for root, _, files in os.walk(unpacked_dir):
        for fn in files:
            if not fn.endswith('.rels'):
                continue
            path = os.path.join(root, fn)
            try:
                rels_tree = ET.parse(path).getroot()
            except ET.ParseError as e:
                errors.append(f"{os.path.relpath(path, unpacked_dir)}: malformed XML — {e}")
                continue
            # Resolve targets relative to the part this rels file describes.
            # rels file at .../foo/_rels/bar.xml.rels describes part .../foo/bar.xml
            # so targets are resolved relative to .../foo/
            # Use exact directory-name match instead of substring-in-path to avoid
            # false-positives on dirs like 'my_relsbackup'.
            if os.path.basename(os.path.dirname(path)) == '_rels':
                part_dir = os.path.dirname(os.path.dirname(path))
            else:
                part_dir = os.path.dirname(path)
            for r in rels_tree:
                tgt = r.get('Target')
                mode = r.get('TargetMode')
                if not tgt or mode == 'External' or tgt.startswith(('http://', 'https://', '#')):
                    continue
                resolved = os.path.normpath(os.path.join(part_dir, tgt))
                if not os.path.exists(resolved):
                    errors.append(
                        f"{os.path.relpath(path, unpacked_dir)}: target does not exist — {tgt}"
                    )
            # Duplicate rId within this rels file
            rids = [r.get('Id') for r in rels_tree if r.get('Id')]
            dups = find_duplicates(rids)
            if dups:
                errors.append(f"{os.path.relpath(path, unpacked_dir)}: duplicate rIds {dups}")

    # ---- 6. [Content_Types].xml present and parseable ----
    ct_path = os.path.join(unpacked_dir, '[Content_Types].xml')
    if not os.path.exists(ct_path):
        errors.append("[Content_Types].xml is missing")
    else:
        try:
            ET.parse(ct_path)
        except ET.ParseError as e:
            errors.append(f"[Content_Types].xml: malformed XML — {e}")

    # ---- Report ----
    if errors:
        print(f"VALIDATION FAILED ({len(errors)} issue{'s' if len(errors) != 1 else ''}):")
        for e in errors:
            print(f"  - {e}")
        return 1
    print(f"OK: {len(slide_files)} slide(s) validated, no integrity issues.")
    return 0


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: validate_pptx_unpacked.py <unpacked_dir>", file=sys.stderr)
        sys.exit(2)
    sys.exit(validate_unpacked(sys.argv[1]))
